import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import Calculator from './components/Calculator';
import CategoryGrid from './components/CategoryGrid';
import CalculatorPage from './components/CalculatorPage';
import SearchResults from './components/SearchResults';
import { calculators } from './data/calculators';

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'calculator' | 'search'>('home');
  const [selectedCalculator, setSelectedCalculator] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [searchResults, setSearchResults] = useState<any[]>([]);

  const handleCalculatorSelect = (calculatorId: string) => {
    setSelectedCalculator(calculatorId);
    setCurrentView('calculator');
  };

  const handleBackToHome = () => {
    setCurrentView('home');
    setSelectedCalculator('');
    setSearchQuery('');
  };

  const handleSearch = (query: string) => {
    if (!query.trim()) {
      setCurrentView('home');
      return;
    }

    const allCalculators = Object.values(calculators).flat();
    const results = allCalculators.filter(calc => 
      calc.name.toLowerCase().includes(query.toLowerCase()) ||
      calc.category.toLowerCase().includes(query.toLowerCase())
    );
    
    setSearchResults(results);
    setSearchQuery(query);
    setCurrentView('search');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <Header onSearch={handleSearch} onHome={handleBackToHome} />
      
      <main className="container mx-auto px-4 py-8">
        {currentView === 'home' && (
          <>
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
                Calculatorz.in
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Free Smart Calculator Hub for Easy All Calculation
              </p>
              
              <div className="max-w-md mx-auto mb-12">
                <Calculator />
              </div>
            </div>
            
            <CategoryGrid onCalculatorSelect={handleCalculatorSelect} />
          </>
        )}
        
        {currentView === 'calculator' && (
          <CalculatorPage 
            calculatorId={selectedCalculator} 
            onBack={handleBackToHome}
          />
        )}
        
        {currentView === 'search' && (
          <SearchResults 
            query={searchQuery}
            results={searchResults}
            onCalculatorSelect={handleCalculatorSelect}
            onBack={handleBackToHome}
          />
        )}
      </main>
      
      <Footer />
    </div>
  );
}

export default App;