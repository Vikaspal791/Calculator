import React from 'react';
import { 
  DollarSign, 
  Heart, 
  Calculator as CalcIcon, 
  Wrench, 
  FileText, 
  Image, 
  Type, 
  ArrowRightLeft,
  TrendingUp,
  Activity,
  Zap,
  Settings
} from 'lucide-react';

interface CategoryGridProps {
  onCalculatorSelect: (calculatorId: string) => void;
}

const CategoryGrid: React.FC<CategoryGridProps> = ({ onCalculatorSelect }) => {
  const categories = [
    {
      id: 'financial',
      title: 'Financial Calculators',
      description: 'Mortgage, loan, investment & currency calculators',
      icon: DollarSign,
      color: 'from-green-400 to-emerald-600',
      count: '50+'
    },
    {
      id: 'health',
      title: 'Fitness & Health',
      description: 'BMI, calorie, body fat & pregnancy calculators',
      icon: Heart,
      color: 'from-red-400 to-pink-600',
      count: '30+'
    },
    {
      id: 'math',
      title: 'Math Calculators',
      description: 'Scientific, percentage, fraction & statistics',
      icon: CalcIcon,
      color: 'from-blue-400 to-indigo-600',
      count: '40+'
    },
    {
      id: 'other',
      title: 'Other Calculators',
      description: 'Age, date, time, GPA & various utility calculators',
      icon: Wrench,
      color: 'from-purple-400 to-violet-600',
      count: '35+'
    },
    {
      id: 'pdf',
      title: 'PDF Tools',
      description: 'Merge, split, compress, convert & edit PDFs',
      icon: FileText,
      color: 'from-orange-400 to-red-600',
      count: '25+'
    },
    {
      id: 'image',
      title: 'Image Tools',
      description: 'Resize, compress, crop & convert images',
      icon: Image,
      color: 'from-cyan-400 to-teal-600',
      count: '15+'
    },
    {
      id: 'font',
      title: 'Font Converters',
      description: 'Unicode, KrutiDev, Preeti & Mangal converters',
      icon: Type,
      color: 'from-amber-400 to-orange-600',
      count: '10+'
    },
    {
      id: 'conversion',
      title: 'Conversion Tools',
      description: 'Unit, currency, temperature & measurement converters',
      icon: ArrowRightLeft,
      color: 'from-lime-400 to-green-600',
      count: '20+'
    }
  ];

  return (
    <div className="py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
          Choose Your Calculator Category
        </h2>
        <p className="text-xl text-gray-600">
          All tools are active and ready to use with just one click!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((category) => {
          const IconComponent = category.icon;
          return (
            <div
              key={category.id}
              onClick={() => onCalculatorSelect(category.id)}
              className="group cursor-pointer bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 transform hover:scale-105 overflow-hidden"
            >
              <div className={`h-32 bg-gradient-to-br ${category.color} flex items-center justify-center relative`}>
                <IconComponent size={48} className="text-white group-hover:scale-110 transition-transform duration-300" />
                <div className="absolute top-4 right-4 bg-white/20 backdrop-blur-sm rounded-full px-3 py-1 text-white text-sm font-semibold">
                  {category.count}
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-blue-600 transition-colors">
                  {category.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed">
                  {category.description}
                </p>
                
                <div className="mt-4 flex items-center text-blue-600 font-semibold text-sm group-hover:text-blue-700">
                  <span>Explore Tools</span>
                  <ArrowRightLeft size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Features Section */}
      <div className="mt-16 bg-white rounded-2xl shadow-lg p-8">
        <div className="text-center mb-8">
          <h3 className="text-2xl font-bold text-gray-800 mb-2">Why Choose Calculatorz.in?</h3>
          <p className="text-gray-600">Fast, accurate, and completely free calculations</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="text-center">
            <div className="bg-gradient-to-r from-blue-500 to-purple-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="text-white" size={24} />
            </div>
            <h4 className="font-semibold text-gray-800 mb-2">Lightning Fast</h4>
            <p className="text-sm text-gray-600">Instant calculations with no waiting time</p>
          </div>
          
          <div className="text-center">
            <div className="bg-gradient-to-r from-green-500 to-teal-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <TrendingUp className="text-white" size={24} />
            </div>
            <h4 className="font-semibold text-gray-800 mb-2">100% Accurate</h4>
            <p className="text-sm text-gray-600">Precise calculations you can trust</p>
          </div>
          
          <div className="text-center">
            <div className="bg-gradient-to-r from-orange-500 to-red-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Activity className="text-white" size={24} />
            </div>
            <h4 className="font-semibold text-gray-800 mb-2">Always Active</h4>
            <p className="text-sm text-gray-600">All tools work instantly, no "coming soon"</p>
          </div>
          
          <div className="text-center">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <Settings className="text-white" size={24} />
            </div>
            <h4 className="font-semibold text-gray-800 mb-2">Mobile Friendly</h4>
            <p className="text-sm text-gray-600">Perfect on any device, anywhere</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CategoryGrid;