import React, { useState } from 'react';
import { Search, Calculator, Phone, Mail, MapPin } from 'lucide-react';

interface HeaderProps {
  onSearch: (query: string) => void;
  onHome: () => void;
}

const Header: React.FC<HeaderProps> = ({ onSearch, onHome }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  return (
    <header className="bg-white shadow-lg border-b-4 border-gradient-to-r from-blue-500 to-purple-500">
      {/* Contact Bar */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-2">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <span className="flex items-center space-x-1">
                <Mail size={14} />
                <span>info@calculatorz.in</span>
              </span>
              <span className="flex items-center space-x-1">
                <Phone size={14} />
                <span>+91 6399933391</span>
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <MapPin size={14} />
              <span>Kankerkhera Meerut, UP 250001</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div 
            className="flex items-center space-x-2 cursor-pointer"
            onClick={onHome}
          >
            <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-lg">
              <Calculator className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Calculatorz
              </h1>
              <p className="text-xs text-gray-500">Smart Calculator Hub</p>
            </div>
          </div>

          <form onSubmit={handleSearchSubmit} className="flex-1 max-w-md mx-8">
            <div className="relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search calculators..."
                className="w-full pl-10 pr-4 py-2 border-2 border-gray-200 rounded-full focus:border-blue-500 focus:outline-none transition-colors"
              />
              <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
            </div>
          </form>

          <div className="hidden md:block">
            <button className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-2 rounded-full hover:shadow-lg transition-all duration-300 transform hover:scale-105">
              Contact Us
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;