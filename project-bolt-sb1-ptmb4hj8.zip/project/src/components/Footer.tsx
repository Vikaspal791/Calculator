import React from 'react';
import { Calculator, Mail, Phone, MapPin, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  const categories = [
    {
      title: 'Financial Calculators',
      calculators: ['Mortgage Calculator', 'Loan Calculator', 'Investment Calculator', 'Currency Calculator']
    },
    {
      title: 'Health & Fitness',
      calculators: ['BMI Calculator', 'Calorie Calculator', 'Body Fat Calculator', 'BMR Calculator']
    },
    {
      title: 'Math Calculators',
      calculators: ['Scientific Calculator', 'Percentage Calculator', 'Fraction Calculator', 'Statistics Calculator']
    },
    {
      title: 'Tools & Converters',
      calculators: ['PDF Tools', 'Image Tools', 'Unit Converter', 'Font Converter']
    }
  ];

  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-2 mb-4">
              <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-lg">
                <Calculator className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-xl font-bold">Calculatorz</h3>
                <p className="text-sm text-gray-400">Smart Calculator Hub</p>
              </div>
            </div>
            <p className="text-gray-400 text-sm mb-4">
              Your one-stop destination for all calculations. Fast, accurate, and free online calculators for every need.
            </p>
            
            <div className="space-y-2 text-sm">
              <div className="flex items-center space-x-2">
                <Mail size={16} className="text-blue-400" />
                <span>info@calculatorz.in</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone size={16} className="text-green-400" />
                <span>+91 6399933391</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin size={16} className="text-red-400" />
                <span>Kankerkhera Meerut, UP 250001</span>
              </div>
            </div>
          </div>

          {/* Calculator Categories */}
          {categories.map((category, index) => (
            <div key={index}>
              <h4 className="text-lg font-semibold mb-4 text-blue-400">{category.title}</h4>
              <ul className="space-y-2">
                {category.calculators.map((calc, calcIndex) => (
                  <li key={calcIndex}>
                    <a 
                      href="#" 
                      className="text-gray-400 hover:text-white transition-colors text-sm"
                    >
                      {calc}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <hr className="border-gray-700 my-8" />

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="text-sm text-gray-400 mb-4 md:mb-0">
            © 2024 Calculatorz.in. All rights reserved. | 
            <a href="#" className="hover:text-white ml-1">Privacy Policy</a> | 
            <a href="#" className="hover:text-white ml-1">Terms of Service</a>
          </div>
          <div className="flex items-center space-x-1 text-sm text-gray-400">
            <span>Made with</span>
            <Heart size={16} className="text-red-500 fill-current" />
            <span>for easy calculations</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;