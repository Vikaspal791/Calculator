import React, { useState } from 'react';
import { DollarSign, TrendingUp, Calculator as CalcIcon } from 'lucide-react';
import { calculators } from '../../data/calculators';
import MortgageCalculator from './financial/MortgageCalculator';
import LoanCalculator from './financial/LoanCalculator';
import InvestmentCalculator from './financial/InvestmentCalculator';

const FinancialCalculators: React.FC = () => {
  const [selectedCalculator, setSelectedCalculator] = useState<string>('');

  const renderCalculator = () => {
    switch (selectedCalculator) {
      case 'mortgage':
        return <MortgageCalculator onBack={() => setSelectedCalculator('')} />;
      case 'loan':
        return <LoanCalculator onBack={() => setSelectedCalculator('')} />;
      case 'investment':
        return <InvestmentCalculator onBack={() => setSelectedCalculator('')} />;
      default:
        return null;
    }
  };

  if (selectedCalculator) {
    return renderCalculator();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.financial.map((calculator) => (
          <div
            key={calculator.id}
            onClick={() => setSelectedCalculator(calculator.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-green-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-3 rounded-lg">
                <DollarSign className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{calculator.name}</h3>
                <p className="text-sm text-green-600">Financial</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{calculator.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-green-600 font-semibold text-sm">Click to Calculate</span>
              <CalcIcon size={20} className="text-green-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FinancialCalculators;