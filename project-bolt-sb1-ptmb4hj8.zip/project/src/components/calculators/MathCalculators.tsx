import React, { useState } from 'react';
import { Calculator as CalcIcon, Hash, TrendingUp } from 'lucide-react';
import { calculators } from '../../data/calculators';
import ScientificCalculator from './math/ScientificCalculator';
import PercentageCalculator from './math/PercentageCalculator';
import FractionCalculator from './math/FractionCalculator';

const MathCalculators: React.FC = () => {
  const [selectedCalculator, setSelectedCalculator] = useState<string>('');

  const renderCalculator = () => {
    switch (selectedCalculator) {
      case 'scientific':
        return <ScientificCalculator onBack={() => setSelectedCalculator('')} />;
      case 'percentage':
        return <PercentageCalculator onBack={() => setSelectedCalculator('')} />;
      case 'fraction':
        return <FractionCalculator onBack={() => setSelectedCalculator('')} />;
      default:
        return null;
    }
  };

  if (selectedCalculator) {
    return renderCalculator();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.math.map((calculator) => (
          <div
            key={calculator.id}
            onClick={() => setSelectedCalculator(calculator.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-blue-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-lg">
                <CalcIcon className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{calculator.name}</h3>
                <p className="text-sm text-blue-600">Mathematics</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{calculator.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-blue-600 font-semibold text-sm">Click to Calculate</span>
              <CalcIcon size={20} className="text-blue-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MathCalculators;