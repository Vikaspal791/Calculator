import React, { useState } from 'react';
import { ArrowLeft, FileText, Upload, Minimize2 } from 'lucide-react';

interface CompressPDFProps {
  onBack: () => void;
}

const CompressPDF: React.FC<CompressPDFProps> = ({ onBack }) => {
  const [file, setFile] = useState<File | null>(null);
  const [compressionLevel, setCompressionLevel] = useState<'low' | 'medium' | 'high'>('medium');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
    }
  };

  const compressPDF = async () => {
    if (!file) {
      alert('Please select a PDF file to compress');
      return;
    }

    setIsProcessing(true);
    
    // Simulate PDF compression process
    setTimeout(() => {
      const compressionRates = { low: 20, medium: 40, high: 65 };
      const reduction = compressionRates[compressionLevel];
      alert(`PDF compressed successfully! File size reduced by approximately ${reduction}%. In a real implementation, this would generate a downloadable compressed PDF file.`);
      setIsProcessing(false);
    }, 3000);
  };

  const getCompressionDescription = (level: string) => {
    switch (level) {
      case 'low':
        return 'Minimal compression, best quality, ~20% size reduction';
      case 'medium':
        return 'Balanced compression, good quality, ~40% size reduction';
      case 'high':
        return 'Maximum compression, smaller size, ~65% size reduction';
      default:
        return '';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to PDF Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-teal-600 p-3 rounded-lg">
            <Minimize2 className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Compress PDF</h1>
            <p className="text-gray-600">Reduce PDF file size while maintaining quality</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* File Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-green-400 transition-colors">
            <input
              type="file"
              accept=".pdf"
              onChange={handleFileSelect}
              className="hidden"
              id="pdf-file"
            />
            <label htmlFor="pdf-file" className="cursor-pointer">
              <Upload size={48} className="text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-700 mb-2">
                Click to select a PDF file
              </p>
              <p className="text-gray-500">
                Or drag and drop a PDF file here
              </p>
            </label>
          </div>

          {/* Selected File */}
          {file && (
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Selected File</h3>
              <div className="flex items-center justify-between bg-white p-4 rounded-lg border">
                <div className="flex items-center space-x-3">
                  <FileText className="text-red-500" size={24} />
                  <div>
                    <p className="font-medium text-gray-800">{file.name}</p>
                    <p className="text-sm text-gray-500">
                      Original size: {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setFile(null)}
                  className="text-red-500 hover:text-red-700 px-3 py-1 rounded-lg hover:bg-red-50 transition-colors"
                >
                  Remove
                </button>
              </div>
            </div>
          )}

          {/* Compression Options */}
          <div className="bg-green-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Compression Level</h3>
            
            <div className="space-y-4">
              {[
                { value: 'low', label: 'Low Compression', color: 'border-blue-500 text-blue-700' },
                { value: 'medium', label: 'Medium Compression', color: 'border-yellow-500 text-yellow-700' },
                { value: 'high', label: 'High Compression', color: 'border-red-500 text-red-700' }
              ].map((option) => (
                <label key={option.value} className="flex items-start space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="compressionLevel"
                    value={option.value}
                    checked={compressionLevel === option.value}
                    onChange={(e) => setCompressionLevel(e.target.value as any)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-gray-700">{option.label}</span>
                      <span className={`px-2 py-1 rounded text-xs border ${option.color} bg-white`}>
                        {option.value.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-sm text-gray-500 mt-1">
                      {getCompressionDescription(option.value)}
                    </p>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Compression Preview */}
          {file && (
            <div className="bg-white border rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Compression Preview</h3>
              <div className="grid grid-cols-2 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-600 mb-2">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </div>
                  <div className="text-sm text-gray-500">Original Size</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600 mb-2">
                    {(file.size / 1024 / 1024 * (compressionLevel === 'low' ? 0.8 : compressionLevel === 'medium' ? 0.6 : 0.35)).toFixed(2)} MB
                  </div>
                  <div className="text-sm text-green-600">Estimated Compressed Size</div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <button
              onClick={compressPDF}
              disabled={!file || isProcessing}
              className="flex-1 bg-gradient-to-r from-green-500 to-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isProcessing ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Compressing PDF...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <Minimize2 size={20} />
                  <span>Compress PDF</span>
                </div>
              )}
            </button>

            <button
              onClick={() => setFile(null)}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear File
            </button>
          </div>

          {/* Instructions */}
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold text-green-800 mb-2">How to use:</h4>
            <ul className="text-sm text-green-700 space-y-1">
              <li>1. Upload a PDF file by clicking or dragging it to the upload area</li>
              <li>2. Choose your preferred compression level based on quality vs size needs</li>
              <li>3. Review the estimated compressed file size</li>
              <li>4. Click "Compress PDF" to reduce the file size</li>
              <li>5. Download the compressed PDF file</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CompressPDF;