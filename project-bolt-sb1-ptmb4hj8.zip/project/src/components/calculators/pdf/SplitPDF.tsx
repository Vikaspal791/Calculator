import React, { useState } from 'react';
import { ArrowLeft, FileText, Upload, Scissors } from 'lucide-react';

interface SplitPDFProps {
  onBack: () => void;
}

const SplitPDF: React.FC<SplitPDFProps> = ({ onBack }) => {
  const [file, setFile] = useState<File | null>(null);
  const [splitOption, setSplitOption] = useState<'pages' | 'range' | 'size'>('pages');
  const [pagesInput, setPagesInput] = useState<string>('1');
  const [rangeInput, setRangeInput] = useState<string>('1-5');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type === 'application/pdf') {
      setFile(selectedFile);
    }
  };

  const splitPDF = async () => {
    if (!file) {
      alert('Please select a PDF file to split');
      return;
    }

    setIsProcessing(true);
    
    // Simulate PDF splitting process
    setTimeout(() => {
      alert('PDF has been split successfully! In a real implementation, this would generate downloadable split PDF files.');
      setIsProcessing(false);
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to PDF Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-lg">
            <Scissors className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Split PDF File</h1>
            <p className="text-gray-600">Extract pages or split PDF into separate documents</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* File Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors">
            <input
              type="file"
              accept=".pdf"
              onChange={handleFileSelect}
              className="hidden"
              id="pdf-file"
            />
            <label htmlFor="pdf-file" className="cursor-pointer">
              <Upload size={48} className="text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-700 mb-2">
                Click to select a PDF file
              </p>
              <p className="text-gray-500">
                Or drag and drop a PDF file here
              </p>
            </label>
          </div>

          {/* Selected File */}
          {file && (
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Selected File</h3>
              <div className="flex items-center space-x-3 bg-white p-4 rounded-lg border">
                <FileText className="text-red-500" size={24} />
                <div>
                  <p className="font-medium text-gray-800">{file.name}</p>
                  <p className="text-sm text-gray-500">
                    {(file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Split Options */}
          <div className="bg-blue-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Split Options</h3>
            
            <div className="space-y-4">
              <label className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="splitOption"
                  value="pages"
                  checked={splitOption === 'pages'}
                  onChange={(e) => setSplitOption(e.target.value as any)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <span className="font-medium text-gray-700">Split by pages</span>
                  <p className="text-sm text-gray-500 mt-1">
                    Split every N pages into separate files
                  </p>
                  {splitOption === 'pages' && (
                    <input
                      type="number"
                      value={pagesInput}
                      onChange={(e) => setPagesInput(e.target.value)}
                      min="1"
                      className="mt-2 w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="1"
                    />
                  )}
                </div>
              </label>

              <label className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="splitOption"
                  value="range"
                  checked={splitOption === 'range'}
                  onChange={(e) => setSplitOption(e.target.value as any)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <span className="font-medium text-gray-700">Extract page range</span>
                  <p className="text-sm text-gray-500 mt-1">
                    Extract specific pages (e.g., 1-5, 10-15)
                  </p>
                  {splitOption === 'range' && (
                    <input
                      type="text"
                      value={rangeInput}
                      onChange={(e) => setRangeInput(e.target.value)}
                      className="mt-2 w-32 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                      placeholder="1-5"
                    />
                  )}
                </div>
              </label>

              <label className="flex items-start space-x-3">
                <input
                  type="radio"
                  name="splitOption"
                  value="size"
                  checked={splitOption === 'size'}
                  onChange={(e) => setSplitOption(e.target.value as any)}
                  className="mt-1"
                />
                <div className="flex-1">
                  <span className="font-medium text-gray-700">Split by file size</span>
                  <p className="text-sm text-gray-500 mt-1">
                    Split into files with maximum size limit
                  </p>
                </div>
              </label>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <button
              onClick={splitPDF}
              disabled={!file || isProcessing}
              className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isProcessing ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Splitting PDF...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <Scissors size={20} />
                  <span>Split PDF</span>
                </div>
              )}
            </button>

            <button
              onClick={() => setFile(null)}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear File
            </button>
          </div>

          {/* Instructions */}
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-800 mb-2">How to use:</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>1. Upload a PDF file by clicking or dragging it to the upload area</li>
              <li>2. Choose how you want to split the PDF (by pages, range, or size)</li>
              <li>3. Configure the split options based on your selection</li>
              <li>4. Click "Split PDF" to process the file</li>
              <li>5. Download the resulting split PDF files</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SplitPDF;