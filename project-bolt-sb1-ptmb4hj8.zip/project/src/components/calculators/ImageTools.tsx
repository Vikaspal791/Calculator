import React, { useState } from 'react';
import { Image, Crop, Compass as Compress } from 'lucide-react';
import { calculators } from '../../data/calculators';
import ImageResizer from './image/ImageResizer';
import ImageCompressor from './image/ImageCompressor';
import CropImage from './image/CropImage';

const ImageTools: React.FC = () => {
  const [selectedTool, setSelectedTool] = useState<string>('');

  const renderTool = () => {
    switch (selectedTool) {
      case 'image-resizer':
        return <ImageResizer onBack={() => setSelectedTool('')} />;
      case 'image-compressor':
        return <ImageCompressor onBack={() => setSelectedTool('')} />;
      case 'crop-image':
        return <CropImage onBack={() => setSelectedTool('')} />;
      default:
        return null;
    }
  };

  if (selectedTool) {
    return renderTool();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.image.map((tool) => (
          <div
            key={tool.id}
            onClick={() => setSelectedTool(tool.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-cyan-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-cyan-500 to-teal-600 p-3 rounded-lg">
                <Image className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{tool.name}</h3>
                <p className="text-sm text-cyan-600">Image Tools</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{tool.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-cyan-600 font-semibold text-sm">Click to Use</span>
              <Image size={20} className="text-cyan-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ImageTools;