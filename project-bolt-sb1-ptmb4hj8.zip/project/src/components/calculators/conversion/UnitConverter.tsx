import React, { useState } from 'react';
import { ArrowLeft, ArrowRightLeft, Ruler } from 'lucide-react';

interface UnitConverterProps {
  onBack: () => void;
}

const UnitConverter: React.FC<UnitConverterProps> = ({ onBack }) => {
  const [category, setCategory] = useState<string>('length');
  const [fromUnit, setFromUnit] = useState<string>('meter');
  const [toUnit, setToUnit] = useState<string>('feet');
  const [inputValue, setInputValue] = useState<number>(1);
  const [result, setResult] = useState<number | null>(null);

  const unitCategories = {
    length: {
      name: 'Length',
      units: {
        meter: { name: 'Meter', factor: 1 },
        kilometer: { name: 'Kilometer', factor: 1000 },
        centimeter: { name: 'Centimeter', factor: 0.01 },
        millimeter: { name: 'Millimeter', factor: 0.001 },
        inch: { name: 'Inch', factor: 0.0254 },
        feet: { name: 'Feet', factor: 0.3048 },
        yard: { name: 'Yard', factor: 0.9144 },
        mile: { name: 'Mile', factor: 1609.34 }
      }
    },
    weight: {
      name: 'Weight',
      units: {
        kilogram: { name: 'Kilogram', factor: 1 },
        gram: { name: 'Gram', factor: 0.001 },
        pound: { name: 'Pound', factor: 0.453592 },
        ounce: { name: 'Ounce', factor: 0.0283495 },
        ton: { name: 'Ton', factor: 1000 },
        stone: { name: 'Stone', factor: 6.35029 }
      }
    },
    volume: {
      name: 'Volume',
      units: {
        liter: { name: 'Liter', factor: 1 },
        milliliter: { name: 'Milliliter', factor: 0.001 },
        gallon: { name: 'Gallon (US)', factor: 3.78541 },
        quart: { name: 'Quart', factor: 0.946353 },
        pint: { name: 'Pint', factor: 0.473176 },
        cup: { name: 'Cup', factor: 0.236588 },
        fluid_ounce: { name: 'Fluid Ounce', factor: 0.0295735 }
      }
    },
    area: {
      name: 'Area',
      units: {
        square_meter: { name: 'Square Meter', factor: 1 },
        square_kilometer: { name: 'Square Kilometer', factor: 1000000 },
        square_centimeter: { name: 'Square Centimeter', factor: 0.0001 },
        square_inch: { name: 'Square Inch', factor: 0.00064516 },
        square_feet: { name: 'Square Feet', factor: 0.092903 },
        acre: { name: 'Acre', factor: 4046.86 },
        hectare: { name: 'Hectare', factor: 10000 }
      }
    }
  };

  const convertUnits = () => {
    const categoryData = unitCategories[category as keyof typeof unitCategories];
    const fromFactor = categoryData.units[fromUnit as keyof typeof categoryData.units].factor;
    const toFactor = categoryData.units[toUnit as keyof typeof categoryData.units].factor;
    
    // Convert to base unit first, then to target unit
    const baseValue = inputValue * fromFactor;
    const convertedValue = baseValue / toFactor;
    
    setResult(convertedValue);
  };

  const swapUnits = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
    if (result !== null) {
      setInputValue(result);
      setResult(inputValue);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Conversion Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-lime-500 to-green-600 p-3 rounded-lg">
            <Ruler className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Unit Converter</h1>
            <p className="text-gray-600">Convert between different units of measurement</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Category Selection */}
          <div className="bg-lime-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Select Category</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries(unitCategories).map(([key, cat]) => (
                <button
                  key={key}
                  onClick={() => {
                    setCategory(key);
                    const units = Object.keys(cat.units);
                    setFromUnit(units[0]);
                    setToUnit(units[1] || units[0]);
                    setResult(null);
                  }}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    category === key
                      ? 'border-lime-500 bg-lime-100'
                      : 'border-gray-200 bg-white hover:border-lime-300'
                  }`}
                >
                  <div className="font-medium text-gray-800">{cat.name}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Conversion Interface */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              {/* From Unit */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">From</label>
                <div className="space-y-3">
                  <select
                    value={fromUnit}
                    onChange={(e) => setFromUnit(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lime-500 focus:border-transparent"
                  >
                    {Object.entries(unitCategories[category as keyof typeof unitCategories].units).map(([key, unit]) => (
                      <option key={key} value={key}>{unit.name}</option>
                    ))}
                  </select>
                  <input
                    type="number"
                    value={inputValue}
                    onChange={(e) => setInputValue(Number(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lime-500 focus:border-transparent text-lg"
                    placeholder="Enter value"
                  />
                </div>
              </div>

              {/* Swap Button */}
              <div className="text-center">
                <button
                  onClick={swapUnits}
                  className="bg-gray-200 hover:bg-gray-300 text-gray-700 p-3 rounded-full transition-colors"
                  title="Swap units"
                >
                  <ArrowRightLeft size={20} />
                </button>
              </div>

              {/* To Unit */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">To</label>
                <div className="space-y-3">
                  <select
                    value={toUnit}
                    onChange={(e) => setToUnit(e.target.value)}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-lime-500 focus:border-transparent"
                  >
                    {Object.entries(unitCategories[category as keyof typeof unitCategories].units).map(([key, unit]) => (
                      <option key={key} value={key}>{unit.name}</option>
                    ))}
                  </select>
                  <div className="w-full px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 text-lg font-semibold text-green-600">
                    {result !== null ? result.toFixed(6).replace(/\.?0+$/, '') : '---'}
                  </div>
                </div>
              </div>

              <button
                onClick={convertUnits}
                className="w-full bg-gradient-to-r from-lime-500 to-green-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                Convert
              </button>
            </div>

            {/* Result Display */}
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Conversion Result</h3>
              
              {result !== null ? (
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border-l-4 border-lime-500">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-lime-600 mb-2">
                        {result.toFixed(6).replace(/\.?0+$/, '')}
                      </div>
                      <div className="text-gray-600">
                        {unitCategories[category as keyof typeof unitCategories].units[toUnit as keyof typeof unitCategories[typeof category]['units']].name}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-800 mb-2">Conversion Formula:</h4>
                    <p className="text-sm text-gray-600">
                      {inputValue} {unitCategories[category as keyof typeof unitCategories].units[fromUnit as keyof typeof unitCategories[typeof category]['units']].name} = {result.toFixed(6).replace(/\.?0+$/, '')} {unitCategories[category as keyof typeof unitCategories].units[toUnit as keyof typeof unitCategories[typeof category]['units']].name}
                    </p>
                  </div>

                  <div className="bg-lime-50 p-4 rounded-lg">
                    <p className="text-sm text-lime-800">
                      ✅ Conversion completed successfully! The result shows {inputValue} {unitCategories[category as keyof typeof unitCategories].units[fromUnit as keyof typeof unitCategories[typeof category]['units']].name.toLowerCase()} equals {result.toFixed(6).replace(/\.?0+$/, '')} {unitCategories[category as keyof typeof unitCategories].units[toUnit as keyof typeof unitCategories[typeof category]['units']].name.toLowerCase()}.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Ruler size={48} className="text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Enter a value and click convert to see results</p>
                </div>
              )}
            </div>
          </div>

          {/* Quick Reference */}
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold text-green-800 mb-2">Quick Reference - {unitCategories[category as keyof typeof unitCategories].name}:</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-green-700">
              {Object.entries(unitCategories[category as keyof typeof unitCategories].units).slice(0, 4).map(([key, unit]) => (
                <div key={key} className="bg-white p-2 rounded">
                  <span className="font-medium">{unit.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Instructions */}
          <div className="bg-lime-50 p-4 rounded-lg">
            <h4 className="font-semibold text-lime-800 mb-2">How to use:</h4>
            <ul className="text-sm text-lime-700 space-y-1">
              <li>1. Select the measurement category (Length, Weight, Volume, or Area)</li>
              <li>2. Choose the unit you want to convert from</li>
              <li>3. Enter the value you want to convert</li>
              <li>4. Select the unit you want to convert to</li>
              <li>5. Click "Convert" to see the result</li>
              <li>6. Use the swap button to quickly reverse the conversion</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UnitConverter;