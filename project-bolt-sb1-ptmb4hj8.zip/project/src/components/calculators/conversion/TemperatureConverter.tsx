import React, { useState } from 'react';
import { ArrowLeft, Thermometer, ArrowRightLeft } from 'lucide-react';

interface TemperatureConverterProps {
  onBack: () => void;
}

const TemperatureConverter: React.FC<TemperatureConverterProps> = ({ onBack }) => {
  const [inputValue, setInputValue] = useState<number>(0);
  const [fromUnit, setFromUnit] = useState<string>('celsius');
  const [toUnit, setToUnit] = useState<string>('fahrenheit');
  const [result, setResult] = useState<number | null>(null);

  const temperatureUnits = {
    celsius: { name: 'Celsius (°C)', symbol: '°C' },
    fahrenheit: { name: 'Fahrenheit (°F)', symbol: '°F' },
    kelvin: { name: 'Kelvin (K)', symbol: 'K' },
    rankine: { name: 'Rankine (°R)', symbol: '°R' }
  };

  const convertTemperature = () => {
    let celsius: number;
    
    // Convert input to Celsius first
    switch (fromUnit) {
      case 'celsius':
        celsius = inputValue;
        break;
      case 'fahrenheit':
        celsius = (inputValue - 32) * 5/9;
        break;
      case 'kelvin':
        celsius = inputValue - 273.15;
        break;
      case 'rankine':
        celsius = (inputValue - 491.67) * 5/9;
        break;
      default:
        celsius = inputValue;
    }
    
    // Convert from Celsius to target unit
    let convertedValue: number;
    switch (toUnit) {
      case 'celsius':
        convertedValue = celsius;
        break;
      case 'fahrenheit':
        convertedValue = celsius * 9/5 + 32;
        break;
      case 'kelvin':
        convertedValue = celsius + 273.15;
        break;
      case 'rankine':
        convertedValue = celsius * 9/5 + 491.67;
        break;
      default:
        convertedValue = celsius;
    }
    
    setResult(convertedValue);
  };

  const swapUnits = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
    if (result !== null) {
      setInputValue(result);
      setResult(inputValue);
    }
  };

  const getTemperatureDescription = (temp: number, unit: string) => {
    if (unit === 'celsius') {
      if (temp < 0) return 'Freezing cold';
      if (temp < 10) return 'Very cold';
      if (temp < 20) return 'Cold';
      if (temp < 25) return 'Cool';
      if (temp < 30) return 'Comfortable';
      if (temp < 35) return 'Warm';
      if (temp < 40) return 'Hot';
      return 'Very hot';
    }
    return '';
  };

  const commonTemperatures = [
    { name: 'Absolute Zero', celsius: -273.15 },
    { name: 'Water Freezing', celsius: 0 },
    { name: 'Room Temperature', celsius: 20 },
    { name: 'Body Temperature', celsius: 37 },
    { name: 'Water Boiling', celsius: 100 }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Conversion Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-red-500 to-orange-600 p-3 rounded-lg">
            <Thermometer className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Temperature Converter</h1>
            <p className="text-gray-600">Convert between Celsius, Fahrenheit, Kelvin, and Rankine</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            {/* From Temperature */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">From</label>
              <div className="space-y-3">
                <select
                  value={fromUnit}
                  onChange={(e) => setFromUnit(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  {Object.entries(temperatureUnits).map(([key, unit]) => (
                    <option key={key} value={key}>{unit.name}</option>
                  ))}
                </select>
                <div className="relative">
                  <input
                    type="number"
                    value={inputValue}
                    onChange={(e) => setInputValue(Number(e.target.value))}
                    className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent text-lg"
                    placeholder="Enter temperature"
                  />
                  <span className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500">
                    {temperatureUnits[fromUnit as keyof typeof temperatureUnits].symbol}
                  </span>
                </div>
              </div>
            </div>

            {/* Swap Button */}
            <div className="text-center">
              <button
                onClick={swapUnits}
                className="bg-gray-200 hover:bg-gray-300 text-gray-700 p-3 rounded-full transition-colors"
                title="Swap units"
              >
                <ArrowRightLeft size={20} />
              </button>
            </div>

            {/* To Temperature */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">To</label>
              <div className="space-y-3">
                <select
                  value={toUnit}
                  onChange={(e) => setToUnit(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                >
                  {Object.entries(temperatureUnits).map(([key, unit]) => (
                    <option key={key} value={key}>{unit.name}</option>
                  ))}
                </select>
                <div className="relative">
                  <div className="w-full px-4 py-3 pr-12 border border-gray-300 rounded-lg bg-gray-50 text-lg font-semibold text-red-600">
                    {result !== null ? result.toFixed(2) : '---'}
                  </div>
                  <span className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-500">
                    {temperatureUnits[toUnit as keyof typeof temperatureUnits].symbol}
                  </span>
                </div>
              </div>
            </div>

            <button
              onClick={convertTemperature}
              className="w-full bg-gradient-to-r from-red-500 to-orange-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Convert Temperature
            </button>
          </div>

          {/* Result Display */}
          <div className="space-y-6">
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Conversion Result</h3>
              
              {result !== null ? (
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border-l-4 border-red-500">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-red-600 mb-2">
                        {result.toFixed(2)}{temperatureUnits[toUnit as keyof typeof temperatureUnits].symbol}
                      </div>
                      <div className="text-gray-600">
                        {temperatureUnits[toUnit as keyof typeof temperatureUnits].name}
                      </div>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-800 mb-2">All Units:</h4>
                    <div className="space-y-2 text-sm">
                      {Object.entries(temperatureUnits).map(([key, unit]) => {
                        let value: number;
                        const celsius = fromUnit === 'celsius' ? inputValue : 
                                       fromUnit === 'fahrenheit' ? (inputValue - 32) * 5/9 :
                                       fromUnit === 'kelvin' ? inputValue - 273.15 :
                                       (inputValue - 491.67) * 5/9;
                        
                        switch (key) {
                          case 'celsius': value = celsius; break;
                          case 'fahrenheit': value = celsius * 9/5 + 32; break;
                          case 'kelvin': value = celsius + 273.15; break;
                          case 'rankine': value = celsius * 9/5 + 491.67; break;
                          default: value = celsius;
                        }
                        
                        return (
                          <div key={key} className="flex justify-between">
                            <span>{unit.name}:</span>
                            <span className="font-semibold">{value.toFixed(2)}{unit.symbol}</span>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {toUnit === 'celsius' && (
                    <div className="bg-orange-50 p-4 rounded-lg">
                      <p className="text-sm text-orange-800">
                        🌡️ {result.toFixed(1)}°C is {getTemperatureDescription(result, 'celsius')}
                      </p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Thermometer size={48} className="text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Enter a temperature and click convert</p>
                </div>
              )}
            </div>

            {/* Common Temperatures */}
            <div className="bg-red-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Common Temperatures</h3>
              <div className="space-y-2">
                {commonTemperatures.map((temp, index) => (
                  <div key={index} className="flex justify-between items-center bg-white p-3 rounded-lg">
                    <span className="font-medium text-gray-700">{temp.name}</span>
                    <div className="text-sm text-gray-600">
                      <span className="font-semibold">{temp.celsius}°C</span>
                      <span className="mx-2">|</span>
                      <span className="font-semibold">{(temp.celsius * 9/5 + 32).toFixed(1)}°F</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Instructions */}
        <div className="mt-8 bg-red-50 p-4 rounded-lg">
          <h4 className="font-semibold text-red-800 mb-2">Temperature Conversion Formulas:</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-red-700">
            <div>
              <p><strong>Celsius to Fahrenheit:</strong> °F = °C × 9/5 + 32</p>
              <p><strong>Fahrenheit to Celsius:</strong> °C = (°F - 32) × 5/9</p>
            </div>
            <div>
              <p><strong>Celsius to Kelvin:</strong> K = °C + 273.15</p>
              <p><strong>Kelvin to Celsius:</strong> °C = K - 273.15</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemperatureConverter;