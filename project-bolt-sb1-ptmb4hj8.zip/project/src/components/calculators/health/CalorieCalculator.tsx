import React, { useState } from 'react';
import { ArrowLeft, Flame } from 'lucide-react';

interface CalorieCalculatorProps {
  onBack: () => void;
}

const CalorieCalculator: React.FC<CalorieCalculatorProps> = ({ onBack }) => {
  const [age, setAge] = useState<number>(30);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [activity, setActivity] = useState<string>('moderate');
  const [result, setResult] = useState<any>(null);

  const calculateCalories = () => {
    // Calculate BMR using Harris-Benedict equation
    let bmr;
    if (gender === 'male') {
      bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
    } else {
      bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
    }

    // Activity multipliers
    const multipliers: { [key: string]: number } = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      very: 1.725,
      extreme: 1.9
    };

    const tdee = bmr * multipliers[activity];

    setResult({
      bmr: Math.round(bmr),
      maintenance: Math.round(tdee),
      weightLoss: Math.round(tdee - 500),
      weightGain: Math.round(tdee + 500)
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Health Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-orange-500 to-red-600 p-3 rounded-lg">
            <Flame className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Calorie Calculator</h1>
            <p className="text-gray-600">Calculate your daily calorie needs</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Age</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'male' | 'female')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Weight (kg)</label>
                <input
                  type="number"
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Height (cm)</label>
                <input
                  type="number"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Activity Level</label>
              <select
                value={activity}
                onChange={(e) => setActivity(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="sedentary">Sedentary (little/no exercise)</option>
                <option value="light">Light (light exercise 1-3 days/week)</option>
                <option value="moderate">Moderate (moderate exercise 3-5 days/week)</option>
                <option value="very">Very Active (hard exercise 6-7 days/week)</option>
                <option value="extreme">Extremely Active (very hard exercise, physical job)</option>
              </select>
            </div>

            <button
              onClick={calculateCalories}
              className="w-full bg-gradient-to-r from-orange-500 to-red-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Calculate Calories
            </button>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Calorie Requirements</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-600">BMR (Basal Metabolic Rate)</span>
                    <span className="text-xl font-bold text-orange-600">{result.bmr} cal</span>
                  </div>
                  <p className="text-xs text-gray-500">Calories burned at rest</p>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Maintenance</span>
                    <span className="font-semibold text-green-600">{result.maintenance} cal</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Weight Loss</span>
                    <span className="font-semibold text-blue-600">{result.weightLoss} cal</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Weight Gain</span>
                    <span className="font-semibold text-purple-600">{result.weightGain} cal</span>
                  </div>
                </div>

                <div className="bg-orange-50 p-4 rounded-lg">
                  <p className="text-sm text-orange-800">
                    🔥 For weight loss, eat {result.weightLoss} calories/day (500 cal deficit). For weight gain, eat {result.weightGain} calories/day (500 cal surplus).
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Flame size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Enter your details to calculate calorie needs</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalorieCalculator;