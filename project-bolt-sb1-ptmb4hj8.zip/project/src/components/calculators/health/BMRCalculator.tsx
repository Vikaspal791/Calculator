import React, { useState } from 'react';
import { ArrowLeft, Zap } from 'lucide-react';

interface BMRCalculatorProps {
  onBack: () => void;
}

const BMRCalculator: React.FC<BMRCalculatorProps> = ({ onBack }) => {
  const [age, setAge] = useState<number>(30);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [result, setResult] = useState<any>(null);

  const calculateBMR = () => {
    let bmr;
    let bmrMifflin;
    
    // Harris-Benedict equation
    if (gender === 'male') {
      bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age);
    } else {
      bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age);
    }

    // Mifflin-St Jeor equation (more accurate)
    if (gender === 'male') {
      bmrMifflin = (10 * weight) + (6.25 * height) - (5 * age) + 5;
    } else {
      bmrMifflin = (10 * weight) + (6.25 * height) - (5 * age) - 161;
    }

    setResult({
      harrisBenedict: Math.round(bmr),
      mifflinStJeor: Math.round(bmrMifflin),
      caloriesPerHour: Math.round(bmrMifflin / 24),
      caloriesPerMinute: Math.round(bmrMifflin / (24 * 60))
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Health Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-yellow-500 to-orange-600 p-3 rounded-lg">
            <Zap className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">BMR Calculator</h1>
            <p className="text-gray-600">Calculate your Basal Metabolic Rate</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Age (years)</label>
                <input
                  type="number"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                  placeholder="30"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Gender</label>
                <select
                  value={gender}
                  onChange={(e) => setGender(e.target.value as 'male' | 'female')}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                >
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Weight (kg)</label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="70"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Height (cm)</label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-yellow-500 focus:border-transparent"
                placeholder="170"
              />
            </div>

            <button
              onClick={calculateBMR}
              className="w-full bg-gradient-to-r from-yellow-500 to-orange-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Calculate BMR
            </button>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">BMR Results</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border-l-4 border-yellow-500">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-600 mb-1">{result.mifflinStJeor}</div>
                    <div className="text-sm text-gray-600">Calories per day</div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <h4 className="font-semibold text-gray-800">Different Methods:</h4>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Mifflin-St Jeor</span>
                    <span className="font-semibold text-yellow-600">{result.mifflinStJeor} cal/day</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Harris-Benedict</span>
                    <span className="font-semibold text-orange-600">{result.harrisBenedict} cal/day</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <h4 className="font-semibold text-gray-800">Breakdown:</h4>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Per Hour</span>
                    <span className="font-semibold">{result.caloriesPerHour} cal</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Per Minute</span>
                    <span className="font-semibold">{result.caloriesPerMinute} cal</span>
                  </div>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    ⚡ BMR represents the minimum calories your body needs to function at rest. This is the energy required for basic bodily functions.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Zap size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Enter your details to calculate BMR</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BMRCalculator;