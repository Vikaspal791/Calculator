import React, { useState } from 'react';
import { ArrowLeft, Activity, Scale } from 'lucide-react';

interface BMICalculatorProps {
  onBack: () => void;
}

const BMICalculator: React.FC<BMICalculatorProps> = ({ onBack }) => {
  const [weight, setWeight] = useState<number>(70);
  const [height, setHeight] = useState<number>(170);
  const [unit, setUnit] = useState<'metric' | 'imperial'>('metric');
  const [result, setResult] = useState<any>(null);

  const calculateBMI = () => {
    let weightKg = weight;
    let heightM = height / 100;

    if (unit === 'imperial') {
      weightKg = weight * 0.453592; // pounds to kg
      heightM = height * 0.0254; // inches to meters
    }

    const bmi = weightKg / (heightM * heightM);
    let category = '';
    let color = '';

    if (bmi < 18.5) {
      category = 'Underweight';
      color = 'text-blue-600';
    } else if (bmi < 25) {
      category = 'Normal weight';
      color = 'text-green-600';
    } else if (bmi < 30) {
      category = 'Overweight';
      color = 'text-yellow-600';
    } else {
      category = 'Obese';
      color = 'text-red-600';
    }

    setResult({
      bmi: bmi.toFixed(1),
      category,
      color
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Health Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-pink-500 to-red-600 p-3 rounded-lg">
            <Scale className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">BMI Calculator</h1>
            <p className="text-gray-600">Calculate your Body Mass Index</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Unit System
              </label>
              <div className="flex space-x-4">
                <button
                  onClick={() => setUnit('metric')}
                  className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                    unit === 'metric' 
                      ? 'bg-pink-500 text-white' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Metric
                </button>
                <button
                  onClick={() => setUnit('imperial')}
                  className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                    unit === 'imperial' 
                      ? 'bg-pink-500 text-white' 
                      : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                  }`}
                >
                  Imperial
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                placeholder={unit === 'metric' ? '70' : '154'}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Height ({unit === 'metric' ? 'cm' : 'inches'})
              </label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                placeholder={unit === 'metric' ? '170' : '67'}
              />
            </div>

            <button
              onClick={calculateBMI}
              className="w-full bg-gradient-to-r from-pink-500 to-red-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Calculate BMI
            </button>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Your BMI Result</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-lg border-l-4 border-pink-500 text-center">
                  <div className="text-4xl font-bold text-pink-600 mb-2">{result.bmi}</div>
                  <div className={`text-xl font-semibold ${result.color}`}>{result.category}</div>
                </div>

                <div className="bg-white p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-3">BMI Categories:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Underweight</span>
                      <span className="text-blue-600">Below 18.5</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Normal weight</span>
                      <span className="text-green-600">18.5 - 24.9</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Overweight</span>
                      <span className="text-yellow-600">25.0 - 29.9</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Obese</span>
                      <span className="text-red-600">30.0 and above</span>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-sm text-blue-800">
                    💡 BMI is a useful measure of overweight and obesity but has limitations. Consult with a healthcare professional for personalized advice.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Activity size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Enter your weight and height to calculate BMI</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default BMICalculator;