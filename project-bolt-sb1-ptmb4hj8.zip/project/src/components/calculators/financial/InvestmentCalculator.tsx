import React, { useState } from 'react';
import { ArrowLeft, TrendingUp, DollarSign } from 'lucide-react';

interface InvestmentCalculatorProps {
  onBack: () => void;
}

const InvestmentCalculator: React.FC<InvestmentCalculatorProps> = ({ onBack }) => {
  const [initialAmount, setInitialAmount] = useState<number>(1000);
  const [monthlyContribution, setMonthlyContribution] = useState<number>(100);
  const [interestRate, setInterestRate] = useState<number>(7);
  const [years, setYears] = useState<number>(10);
  const [result, setResult] = useState<any>(null);

  const calculateInvestment = () => {
    const monthlyRate = interestRate / 100 / 12;
    const months = years * 12;
    
    // Future value of initial investment
    const futureValueInitial = initialAmount * Math.pow(1 + monthlyRate, months);
    
    // Future value of monthly contributions (annuity)
    const futureValueAnnuity = monthlyContribution * (Math.pow(1 + monthlyRate, months) - 1) / monthlyRate;
    
    const totalValue = futureValueInitial + futureValueAnnuity;
    const totalContributed = initialAmount + (monthlyContribution * months);
    const totalEarnings = totalValue - totalContributed;

    setResult({
      finalAmount: totalValue.toFixed(2),
      totalContributed: totalContributed.toFixed(2),
      totalEarnings: totalEarnings.toFixed(2),
      returnOnInvestment: ((totalEarnings / totalContributed) * 100).toFixed(2)
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Financial Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-lg">
            <TrendingUp className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Investment Calculator</h1>
            <p className="text-gray-600">Calculate your investment growth over time</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Initial Investment ($)
              </label>
              <input
                type="number"
                value={initialAmount}
                onChange={(e) => setInitialAmount(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="1,000"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Monthly Contribution ($)
              </label>
              <input
                type="number"
                value={monthlyContribution}
                onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="100"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Annual Return Rate (%)
              </label>
              <input
                type="number"
                step="0.1"
                value={interestRate}
                onChange={(e) => setInterestRate(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="7.0"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Investment Period (Years)
              </label>
              <input
                type="number"
                value={years}
                onChange={(e) => setYears(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="10"
              />
            </div>

            <button
              onClick={calculateInvestment}
              className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Calculate Investment
            </button>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Investment Projection</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border-l-4 border-purple-500">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Final Amount</span>
                    <span className="text-2xl font-bold text-purple-600">${result.finalAmount}</span>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Total Contributed</span>
                    <span className="font-semibold">${result.totalContributed}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Total Earnings</span>
                    <span className="font-semibold text-green-600">${result.totalEarnings}</span>
                  </div>
                  <div className="flex items-center justify-between border-t pt-2">
                    <span className="text-gray-600 font-semibold">Return on Investment</span>
                    <span className="font-bold text-blue-600">{result.returnOnInvestment}%</span>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-4 rounded-lg">
                  <p className="text-sm text-purple-800">
                    🚀 Your investment could grow to <strong>${result.finalAmount}</strong> in {years} years with consistent contributions!
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <DollarSign size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Enter your investment details to see projections</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvestmentCalculator;