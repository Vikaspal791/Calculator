import React, { useState } from 'react';
import { ArrowLeft, Image, Upload, Maximize2 } from 'lucide-react';

interface ImageResizerProps {
  onBack: () => void;
}

const ImageResizer: React.FC<ImageResizerProps> = ({ onBack }) => {
  const [file, setFile] = useState<File | null>(null);
  const [originalDimensions, setOriginalDimensions] = useState<{ width: number; height: number } | null>(null);
  const [newWidth, setNewWidth] = useState<number>(800);
  const [newHeight, setNewHeight] = useState<number>(600);
  const [maintainRatio, setMaintainRatio] = useState<boolean>(true);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type.startsWith('image/')) {
      setFile(selectedFile);
      
      // Get image dimensions
      const img = new Image();
      img.onload = () => {
        setOriginalDimensions({ width: img.width, height: img.height });
        setNewWidth(img.width);
        setNewHeight(img.height);
      };
      img.src = URL.createObjectURL(selectedFile);
    }
  };

  const handleWidthChange = (width: number) => {
    setNewWidth(width);
    if (maintainRatio && originalDimensions) {
      const ratio = originalDimensions.height / originalDimensions.width;
      setNewHeight(Math.round(width * ratio));
    }
  };

  const handleHeightChange = (height: number) => {
    setNewHeight(height);
    if (maintainRatio && originalDimensions) {
      const ratio = originalDimensions.width / originalDimensions.height;
      setNewWidth(Math.round(height * ratio));
    }
  };

  const resizeImage = async () => {
    if (!file) {
      alert('Please select an image file to resize');
      return;
    }

    setIsProcessing(true);
    
    // Simulate image resizing process
    setTimeout(() => {
      alert(`Image resized successfully to ${newWidth}x${newHeight} pixels! In a real implementation, this would generate a downloadable resized image file.`);
      setIsProcessing(false);
    }, 2000);
  };

  const presets = [
    { name: 'Instagram Square', width: 1080, height: 1080 },
    { name: 'Instagram Story', width: 1080, height: 1920 },
    { name: 'Facebook Cover', width: 1200, height: 630 },
    { name: 'Twitter Header', width: 1500, height: 500 },
    { name: 'LinkedIn Banner', width: 1584, height: 396 },
    { name: 'YouTube Thumbnail', width: 1280, height: 720 }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Image Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-cyan-500 to-teal-600 p-3 rounded-lg">
            <Maximize2 className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Image Resizer</h1>
            <p className="text-gray-600">Resize images to any dimensions while maintaining quality</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* File Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-cyan-400 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              id="image-file"
            />
            <label htmlFor="image-file" className="cursor-pointer">
              <Upload size={48} className="text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-700 mb-2">
                Click to select an image file
              </p>
              <p className="text-gray-500">
                Supports JPG, PNG, GIF, WebP and other image formats
              </p>
            </label>
          </div>

          {/* Selected File and Preview */}
          {file && originalDimensions && (
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Selected Image</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-4 rounded-lg">
                  <img
                    src={URL.createObjectURL(file)}
                    alt="Selected image"
                    className="w-full h-48 object-contain rounded-lg"
                  />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Image className="text-cyan-500" size={24} />
                    <div>
                      <p className="font-medium text-gray-800">{file.name}</p>
                      <p className="text-sm text-gray-500">
                        {originalDimensions.width}x{originalDimensions.height} pixels
                      </p>
                      <p className="text-sm text-gray-500">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Resize Options */}
          {originalDimensions && (
            <div className="bg-cyan-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Resize Options</h3>
              
              <div className="space-y-6">
                {/* Preset Sizes */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Quick Presets</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {presets.map((preset) => (
                      <button
                        key={preset.name}
                        onClick={() => {
                          setNewWidth(preset.width);
                          setNewHeight(preset.height);
                          setMaintainRatio(false);
                        }}
                        className="p-3 text-left bg-white border border-gray-200 rounded-lg hover:border-cyan-400 hover:shadow-md transition-all"
                      >
                        <div className="font-medium text-gray-800 text-sm">{preset.name}</div>
                        <div className="text-xs text-gray-500">{preset.width}×{preset.height}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom Dimensions */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Custom Dimensions</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-2">Width (px)</label>
                      <input
                        type="number"
                        value={newWidth}
                        onChange={(e) => handleWidthChange(Number(e.target.value))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-600 mb-2">Height (px)</label>
                      <input
                        type="number"
                        value={newHeight}
                        onChange={(e) => handleHeightChange(Number(e.target.value))}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-cyan-500"
                      />
                    </div>
                  </div>
                  
                  <label className="flex items-center space-x-3 mt-4">
                    <input
                      type="checkbox"
                      checked={maintainRatio}
                      onChange={(e) => setMaintainRatio(e.target.checked)}
                      className="rounded"
                    />
                    <span className="text-gray-700">Maintain aspect ratio</span>
                  </label>
                </div>

                {/* Size Comparison */}
                <div className="bg-white p-4 rounded-lg">
                  <h4 className="font-medium text-gray-700 mb-3">Size Comparison</h4>
                  <div className="grid grid-cols-2 gap-6 text-center">
                    <div>
                      <div className="text-lg font-semibold text-gray-600">Original</div>
                      <div className="text-cyan-600">{originalDimensions.width}×{originalDimensions.height}</div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-gray-600">New Size</div>
                      <div className="text-teal-600">{newWidth}×{newHeight}</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <button
              onClick={resizeImage}
              disabled={!file || isProcessing}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isProcessing ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Resizing Image...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <Maximize2 size={20} />
                  <span>Resize Image</span>
                </div>
              )}
            </button>

            <button
              onClick={() => {
                setFile(null);
                setOriginalDimensions(null);
              }}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear Image
            </button>
          </div>

          {/* Instructions */}
          <div className="bg-cyan-50 p-4 rounded-lg">
            <h4 className="font-semibold text-cyan-800 mb-2">How to use:</h4>
            <ul className="text-sm text-cyan-700 space-y-1">
              <li>1. Upload an image file by clicking or dragging it to the upload area</li>
              <li>2. Choose a preset size or enter custom dimensions</li>
              <li>3. Toggle "Maintain aspect ratio" to prevent image distortion</li>
              <li>4. Preview the size comparison between original and new dimensions</li>
              <li>5. Click "Resize Image" to process and download the resized image</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageResizer;