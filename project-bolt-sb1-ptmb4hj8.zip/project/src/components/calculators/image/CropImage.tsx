import React, { useState } from 'react';
import { ArrowLeft, Image, Upload, Crop } from 'lucide-react';

interface CropImageProps {
  onBack: () => void;
}

const CropImage: React.FC<CropImageProps> = ({ onBack }) => {
  const [file, setFile] = useState<File | null>(null);
  const [cropMode, setCropMode] = useState<'freeform' | 'square' | 'rectangle' | 'circle'>('freeform');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type.startsWith('image/')) {
      setFile(selectedFile);
    }
  };

  const cropImage = async () => {
    if (!file) {
      alert('Please select an image file to crop');
      return;
    }

    setIsProcessing(true);
    
    // Simulate image cropping process
    setTimeout(() => {
      alert(`Image cropped successfully using ${cropMode} mode! In a real implementation, this would provide an interactive cropping interface and generate a downloadable cropped image.`);
      setIsProcessing(false);
    }, 2000);
  };

  const aspectRatios = [
    { name: 'Square (1:1)', ratio: '1:1', description: 'Perfect for social media profile pictures' },
    { name: 'Landscape (16:9)', ratio: '16:9', description: 'Great for wide banners and thumbnails' },
    { name: 'Portrait (9:16)', ratio: '9:16', description: 'Ideal for mobile screens and stories' },
    { name: 'Photo (4:3)', ratio: '4:3', description: 'Traditional photo format' },
    { name: 'Golden Ratio', ratio: '1.618:1', description: 'Aesthetically pleasing proportions' },
    { name: 'Custom', ratio: 'custom', description: 'Set your own dimensions' }
  ];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Image Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-3 rounded-lg">
            <Crop className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Crop Image</h1>
            <p className="text-gray-600">Crop and trim images to the perfect size</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* File Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-green-400 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              id="image-file"
            />
            <label htmlFor="image-file" className="cursor-pointer">
              <Upload size={48} className="text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-700 mb-2">
                Click to select an image file
              </p>
              <p className="text-gray-500">
                Supports JPG, PNG, GIF, WebP and other image formats
              </p>
            </label>
          </div>

          {/* Selected File and Preview */}
          {file && (
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Selected Image</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-4 rounded-lg">
                  <img
                    src={URL.createObjectURL(file)}
                    alt="Selected image"
                    className="w-full h-64 object-contain rounded-lg border-2 border-dashed border-gray-300"
                  />
                  <p className="text-center text-sm text-gray-500 mt-2">
                    Click and drag to select crop area
                  </p>
                </div>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Image className="text-green-500" size={24} />
                    <div>
                      <p className="font-medium text-gray-800">{file.name}</p>
                      <p className="text-sm text-gray-500">
                        Size: {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                      <p className="text-sm text-gray-500">
                        Type: {file.type}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Crop Options */}
          {file && (
            <div className="bg-green-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Crop Settings</h3>
              
              <div className="space-y-6">
                {/* Crop Mode */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Crop Mode</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { value: 'freeform', label: 'Freeform', desc: 'Any shape' },
                      { value: 'square', label: 'Square', desc: '1:1 ratio' },
                      { value: 'rectangle', label: 'Rectangle', desc: 'Fixed ratio' },
                      { value: 'circle', label: 'Circle', desc: 'Round crop' }
                    ].map((mode) => (
                      <button
                        key={mode.value}
                        onClick={() => setCropMode(mode.value as any)}
                        className={`p-3 text-left border rounded-lg transition-all ${
                          cropMode === mode.value
                            ? 'border-green-500 bg-green-100'
                            : 'border-gray-200 bg-white hover:border-green-300'
                        }`}
                      >
                        <div className="font-medium text-gray-800 text-sm">{mode.label}</div>
                        <div className="text-xs text-gray-500">{mode.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Aspect Ratio Presets */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Aspect Ratio Presets</h4>
                  <div className="grid grid-cols-2 md: gap-3">
                    {aspectRatios.map((preset) => (
                      <button
                        key={preset.ratio}
                        className="p-3 text-left bg-white border border-gray-200 rounded-lg hover:border-green-400 hover:shadow-md transition-all"
                      >
                        <div className="font-medium text-gray-800 text-sm">{preset.name}</div>
                        <div className="text-xs text-gray-500">{preset.description}</div>
                        <div className="text-xs font-semibold text-green-600">{preset.ratio}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Crop Preview */}
                <div className="bg-white p-4 rounded-lg">
                  <h4 className="font-medium text-gray-700 mb-3">Crop Preview</h4>
                  <div className="text-center">
                    <div className="inline-block p-4 border-2 border-dashed border-green-400 rounded-lg">
                      <Crop size={48} className="text-green-500 mx-auto mb-2" />
                      <p className="text-sm text-gray-600">
                        Interactive crop area will appear here
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Drag corners to resize, drag center to move
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <button
              onClick={cropImage}
              disabled={!file || isProcessing}
              className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isProcessing ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Cropping Image...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <Crop size={20} />
                  <span>Crop Image</span>
                </div>
              )}
            </button>

            <button
              onClick={() => setFile(null)}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear Image
            </button>
          </div>

          {/* Instructions */}
          <div className="bg-green-50 p-4 rounded-lg">
            <h4 className="font-semibold text-green-800 mb-2">How to use:</h4>
            <ul className="text-sm text-green-700 space-y-1">
              <li>1. Upload an image file by clicking or dragging it to the upload area</li>
              <li>2. Choose your preferred crop mode (freeform, square, rectangle, or circle)</li>
              <li>3. Select an aspect ratio preset or use custom dimensions</li>
              <li>4. Drag the crop area on the image to select the portion you want to keep</li>
              <li>5. Click "Crop Image" to process and download the cropped image</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CropImage;