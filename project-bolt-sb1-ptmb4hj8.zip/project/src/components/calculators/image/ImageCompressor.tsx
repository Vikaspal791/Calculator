import React, { useState } from 'react';
import { ArrowLeft, Image, Upload, Minimize2 } from 'lucide-react';

interface ImageCompressorProps {
  onBack: () => void;
}

const ImageCompressor: React.FC<ImageCompressorProps> = ({ onBack }) => {
  const [file, setFile] = useState<File | null>(null);
  const [quality, setQuality] = useState<number>(80);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type.startsWith('image/')) {
      setFile(selectedFile);
    }
  };

  const compressImage = async () => {
    if (!file) {
      alert('Please select an image file to compress');
      return;
    }

    setIsProcessing(true);
    
    // Simulate image compression process
    setTimeout(() => {
      const estimatedReduction = Math.round((100 - quality) * 0.8);
      alert(`Image compressed successfully! Estimated ${estimatedReduction}% size reduction. In a real implementation, this would generate a downloadable compressed image file.`);
      setIsProcessing(false);
    }, 2000);
  };

  const getQualityDescription = (quality: number) => {
    if (quality >= 90) return 'Highest quality, minimal compression';
    if (quality >= 70) return 'High quality, moderate compression';
    if (quality >= 50) return 'Good quality, significant compression';
    if (quality >= 30) return 'Lower quality, high compression';
    return 'Lowest quality, maximum compression';
  };

  const estimateCompressedSize = (originalSize: number, quality: number) => {
    const compressionFactor = quality / 100;
    return originalSize * compressionFactor * 0.7; // Rough estimation
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Image Tools</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-lg">
            <Minimize2 className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Image Compressor</h1>
            <p className="text-gray-600">Reduce image file size while maintaining visual quality</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* File Upload Area */}
          <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-purple-400 transition-colors">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileSelect}
              className="hidden"
              id="image-file"
            />
            <label htmlFor="image-file" className="cursor-pointer">
              <Upload size={48} className="text-gray-400 mx-auto mb-4" />
              <p className="text-lg font-semibold text-gray-700 mb-2">
                Click to select an image file
              </p>
              <p className="text-gray-500">
                Supports JPG, PNG, WebP and other image formats
              </p>
            </label>
          </div>

          {/* Selected File and Preview */}
          {file && (
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Selected Image</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-white p-4 rounded-lg">
                  <img
                    src={URL.createObjectURL(file)}
                    alt="Selected image"
                    className="w-full h-48 object-contain rounded-lg"
                  />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Image className="text-purple-500" size={24} />
                    <div>
                      <p className="font-medium text-gray-800">{file.name}</p>
                      <p className="text-sm text-gray-500">
                        Original size: {(file.size / 1024 / 1024).toFixed(2)} MB
                      </p>
                      <p className="text-sm text-gray-500">
                        Type: {file.type}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Compression Options */}
          {file && (
            <div className="bg-purple-50 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Compression Settings</h3>
              
              <div className="space-y-6">
                {/* Quality Slider */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <label className="font-medium text-gray-700">Quality Level</label>
                    <span className="text-2xl font-bold text-purple-600">{quality}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={quality}
                    onChange={(e) => setQuality(Number(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-2">
                    <span>Smallest file</span>
                    <span>Best quality</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">{getQualityDescription(quality)}</p>
                </div>

                {/* Quick Presets */}
                <div>
                  <h4 className="font-medium text-gray-700 mb-3">Quick Presets</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { label: 'Web Optimized', value: 75, desc: 'Good for websites' },
                      { label: 'High Quality', value: 90, desc: 'Minimal compression' },
                      { label: 'Balanced', value: 60, desc: 'Good quality & size' },
                      { label: 'Small Size', value: 40, desc: 'Maximum compression' }
                    ].map((preset) => (
                      <button
                        key={preset.value}
                        onClick={() => setQuality(preset.value)}
                        className={`p-3 text-left border rounded-lg transition-all ${
                          quality === preset.value
                            ? 'border-purple-500 bg-purple-100'
                            : 'border-gray-200 bg-white hover:border-purple-300'
                        }`}
                      >
                        <div className="font-medium text-gray-800 text-sm">{preset.label}</div>
                        <div className="text-xs text-gray-500">{preset.desc}</div>
                        <div className="text-xs font-semibold text-purple-600">{preset.value}%</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Size Comparison */}
                <div className="bg-white p-4 rounded-lg">
                  <h4 className="font-medium text-gray-700 mb-3">Size Comparison</h4>
                  <div className="grid grid-cols-2 gap-6 text-center">
                    <div>
                      <div className="text-lg font-semibold text-gray-600">Original</div>
                      <div className="text-purple-600 text-xl font-bold">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </div>
                    </div>
                    <div>
                      <div className="text-lg font-semibold text-gray-600">Compressed</div>
                      <div className="text-pink-600 text-xl font-bold">
                        {(estimateCompressedSize(file.size, quality) / 1024 / 1024).toFixed(2)} MB
                      </div>
                      <div className="text-sm text-green-600">
                        ~{Math.round((1 - estimateCompressedSize(file.size, quality) / file.size) * 100)}% reduction
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <button
              onClick={compressImage}
              disabled={!file || isProcessing}
              className="flex-1 bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {isProcessing ? (
                <div className="flex items-center justify-center space-x-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Compressing Image...</span>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-2">
                  <Minimize2 size={20} />
                  <span>Compress Image</span>
                </div>
              )}
            </button>

            <button
              onClick={() => setFile(null)}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear Image
            </button>
          </div>

          {/* Instructions */}
          <div className="bg-purple-50 p-4 rounded-lg">
            <h4 className="font-semibold text-purple-800 mb-2">How to use:</h4>
            <ul className="text-sm text-purple-700 space-y-1">
              <li>1. Upload an image file by clicking or dragging it to the upload area</li>
              <li>2. Adjust the quality slider or choose a preset based on your needs</li>
              <li>3. Preview the estimated file size reduction</li>
              <li>4. Click "Compress Image" to process the file</li>
              <li>5. Download the compressed image with reduced file size</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageCompressor;