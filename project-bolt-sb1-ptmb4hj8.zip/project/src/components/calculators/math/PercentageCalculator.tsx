import React, { useState } from 'react';
import { ArrowLeft, Percent } from 'lucide-react';

interface PercentageCalculatorProps {
  onBack: () => void;
}

const PercentageCalculator: React.FC<PercentageCalculatorProps> = ({ onBack }) => {
  const [value1, setValue1] = useState<number>(50);
  const [value2, setValue2] = useState<number>(200);
  const [percentage, setPercentage] = useState<number>(25);
  const [results, setResults] = useState<any>(null);

  const calculatePercentages = () => {
    const percentOf = (value1 / value2) * 100;
    const percentageOfValue = (percentage * value2) / 100;
    const percentIncrease = ((value2 - value1) / value1) * 100;
    const percentDecrease = ((value1 - value2) / value1) * 100;

    setResults({
      percentOf: percentOf.toFixed(2),
      percentageOfValue: percentageOfValue.toFixed(2),
      percentIncrease: percentIncrease.toFixed(2),
      percentDecrease: Math.abs(percentDecrease).toFixed(2),
      isIncrease: value2 > value1
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Math Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-teal-600 p-3 rounded-lg">
            <Percent className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Percentage Calculator</h1>
            <p className="text-gray-600">Calculate percentages, increases, and decreases</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Input Values</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    First Value
                  </label>
                  <input
                    type="number"
                    value={value1}
                    onChange={(e) => setValue1(Number(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="50"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Second Value
                  </label>
                  <input
                    type="number"
                    value={value2}
                    onChange={(e) => setValue2(Number(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="200"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Percentage (%)
                  </label>
                  <input
                    type="number"
                    value={percentage}
                    onChange={(e) => setPercentage(Number(e.target.value))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    placeholder="25"
                  />
                </div>
              </div>

              <button
                onClick={calculatePercentages}
                className="w-full mt-6 bg-gradient-to-r from-green-500 to-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                Calculate All Percentages
              </button>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Results</h3>
              
              {results ? (
                <div className="space-y-4">
                  <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">What % is {value1} of {value2}?</span>
                      <span className="text-xl font-bold text-green-600">{results.percentOf}%</span>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">What is {percentage}% of {value2}?</span>
                      <span className="text-xl font-bold text-blue-600">{results.percentageOfValue}</span>
                    </div>
                  </div>

                  <div className="bg-white p-4 rounded-lg border-l-4 border-orange-500">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">
                        % {results.isIncrease ? 'Increase' : 'Decrease'} from {value1} to {value2}
                      </span>
                      <span className={`text-xl font-bold ${results.isIncrease ? 'text-green-600' : 'text-red-600'}`}>
                        {results.isIncrease ? '+' : '-'}{results.isIncrease ? results.percentIncrease : results.percentDecrease}%
                      </span>
                    </div>
                  </div>

                  <div className="bg-gradient-to-r from-green-50 to-teal-50 p-4 rounded-lg">
                    <h4 className="font-semibold text-gray-800 mb-2">Quick Reference:</h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>• {value1} is {results.percentOf}% of {value2}</p>
                      <p>• {percentage}% of {value2} = {results.percentageOfValue}</p>
                      <p>• Change from {value1} to {value2} = {results.isIncrease ? '+' : ''}{results.isIncrease ? results.percentIncrease : -results.percentDecrease}%</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Percent size={48} className="text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Enter values and click calculate to see results</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PercentageCalculator;