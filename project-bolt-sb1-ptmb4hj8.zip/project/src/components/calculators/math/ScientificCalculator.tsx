import React, { useState } from 'react';
import { ArrowLeft, Calculator as CalcIcon } from 'lucide-react';

interface ScientificCalculatorProps {
  onBack: () => void;
}

const ScientificCalculator: React.FC<ScientificCalculatorProps> = ({ onBack }) => {
  const [display, setDisplay] = useState('0');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);

  const inputNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      setWaitingForNewValue(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const inputOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue || 0;
      const newValue = calculate(currentValue, inputValue, operation);

      setDisplay(String(newValue));
      setPreviousValue(newValue);
    }

    setWaitingForNewValue(true);
    setOperation(nextOperation);
  };

  const calculate = (firstValue: number, secondValue: number, operation: string) => {
    switch (operation) {
      case '+': return firstValue + secondValue;
      case '-': return firstValue - secondValue;
      case '×': return firstValue * secondValue;
      case '÷': return firstValue / secondValue;
      case '^': return Math.pow(firstValue, secondValue);
      default: return secondValue;
    }
  };

  const scientificOperation = (op: string) => {
    const value = parseFloat(display);
    let result: number;

    switch (op) {
      case 'sin': result = Math.sin(value * Math.PI / 180); break;
      case 'cos': result = Math.cos(value * Math.PI / 180); break;
      case 'tan': result = Math.tan(value * Math.PI / 180); break;
      case 'log': result = Math.log10(value); break;
      case 'ln': result = Math.log(value); break;
      case 'sqrt': result = Math.sqrt(value); break;
      case '1/x': result = 1 / value; break;
      case 'x²': result = value * value; break;
      case '!': result = factorial(value); break;
      default: result = value;
    }

    setDisplay(String(result));
    setWaitingForNewValue(true);
  };

  const factorial = (n: number): number => {
    if (n < 0 || n !== Math.floor(n)) return NaN;
    if (n === 0 || n === 1) return 1;
    return n * factorial(n - 1);
  };

  const clear = () => {
    setDisplay('0');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const performCalculation = () => {
    const inputValue = parseFloat(display);

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation);
      setDisplay(String(newValue));
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Math Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-600 p-3 rounded-lg">
            <CalcIcon className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Scientific Calculator</h1>
            <p className="text-gray-600">Advanced mathematical calculations</p>
          </div>
        </div>

        <div className="bg-gray-900 text-white p-4 rounded-lg text-right text-2xl font-mono mb-6 min-h-[60px] flex items-center justify-end">
          {display}
        </div>

        <div className="grid grid-cols-6 gap-3">
          {/* Scientific Functions Row 1 */}
          <button onClick={() => scientificOperation('sin')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">sin</button>
          <button onClick={() => scientificOperation('cos')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">cos</button>
          <button onClick={() => scientificOperation('tan')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">tan</button>
          <button onClick={() => scientificOperation('log')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">log</button>
          <button onClick={() => scientificOperation('ln')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">ln</button>
          <button onClick={() => scientificOperation('!')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">x!</button>

          {/* Scientific Functions Row 2 */}
          <button onClick={() => scientificOperation('sqrt')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">√</button>
          <button onClick={() => scientificOperation('x²')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">x²</button>
          <button onClick={() => inputOperation('^')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">x^y</button>
          <button onClick={() => scientificOperation('1/x')} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">1/x</button>
          <button onClick={() => inputNumber(Math.PI.toString())} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">π</button>
          <button onClick={() => inputNumber(Math.E.toString())} className="bg-gray-500 hover:bg-gray-600 text-white py-3 rounded-lg font-semibold">e</button>

          {/* Standard Calculator Functions */}
          <button onClick={clear} className="bg-red-500 hover:bg-red-600 text-white py-3 rounded-lg font-semibold">C</button>
          <button onClick={() => setDisplay(display.slice(0, -1) || '0')} className="bg-orange-500 hover:bg-orange-600 text-white py-3 rounded-lg font-semibold">⌫</button>
          <button onClick={() => inputOperation('÷')} className="bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold">÷</button>
          <button onClick={() => inputOperation('×')} className="bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold">×</button>
          <button onClick={() => inputOperation('-')} className="bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold">-</button>
          <button onClick={() => inputOperation('+')} className="bg-blue-500 hover:bg-blue-600 text-white py-3 rounded-lg font-semibold">+</button>

          {/* Number Pad */}
          <button onClick={() => inputNumber('7')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">7</button>
          <button onClick={() => inputNumber('8')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">8</button>
          <button onClick={() => inputNumber('9')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">9</button>
          <button onClick={() => inputNumber('4')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">4</button>
          <button onClick={() => inputNumber('5')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">5</button>
          <button onClick={() => inputNumber('6')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">6</button>

          <button onClick={() => inputNumber('1')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">1</button>
          <button onClick={() => inputNumber('2')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">2</button>
          <button onClick={() => inputNumber('3')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">3</button>
          <button onClick={() => inputNumber('0')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold col-span-2">0</button>
          <button onClick={() => setDisplay(display.includes('.') ? display : display + '.')} className="bg-gray-200 hover:bg-gray-300 text-gray-800 py-3 rounded-lg font-semibold">.</button>

          <button onClick={performCalculation} className="bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-semibold col-span-6">=</button>
        </div>
      </div>
    </div>
  );
};

export default ScientificCalculator;