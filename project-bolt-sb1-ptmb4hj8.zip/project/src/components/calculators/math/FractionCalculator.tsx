import React, { useState } from 'react';
import { ArrowLeft, Divide } from 'lucide-react';

interface FractionCalculatorProps {
  onBack: () => void;
}

const FractionCalculator: React.FC<FractionCalculatorProps> = ({ onBack }) => {
  const [num1, setNum1] = useState<number>(1);
  const [den1, setDen1] = useState<number>(2);
  const [num2, setNum2] = useState<number>(1);
  const [den2, setDen2] = useState<number>(3);
  const [operation, setOperation] = useState<string>('+');
  const [result, setResult] = useState<any>(null);

  const gcd = (a: number, b: number): number => {
    return b === 0 ? a : gcd(b, a % b);
  };

  const simplifyFraction = (numerator: number, denominator: number) => {
    const divisor = gcd(Math.abs(numerator), Math.abs(denominator));
    return {
      numerator: numerator / divisor,
      denominator: denominator / divisor
    };
  };

  const calculateFractions = () => {
    let resultNum: number;
    let resultDen: number;

    switch (operation) {
      case '+':
        resultNum = (num1 * den2) + (num2 * den1);
        resultDen = den1 * den2;
        break;
      case '-':
        resultNum = (num1 * den2) - (num2 * den1);
        resultDen = den1 * den2;
        break;
      case '×':
        resultNum = num1 * num2;
        resultDen = den1 * den2;
        break;
      case '÷':
        resultNum = num1 * den2;
        resultDen = den1 * num2;
        break;
      default:
        resultNum = 0;
        resultDen = 1;
    }

    const simplified = simplifyFraction(resultNum, resultDen);
    const decimal = simplified.numerator / simplified.denominator;
    const percentage = (decimal * 100).toFixed(2);

    setResult({
      original: { numerator: resultNum, denominator: resultDen },
      simplified: simplified,
      decimal: decimal.toFixed(4),
      percentage: percentage,
      isImproper: Math.abs(simplified.numerator) > Math.abs(simplified.denominator),
      mixedNumber: simplified.denominator !== 0 && Math.abs(simplified.numerator) > Math.abs(simplified.denominator) 
        ? {
            whole: Math.floor(Math.abs(simplified.numerator) / Math.abs(simplified.denominator)) * (simplified.numerator < 0 ? -1 : 1),
            numerator: Math.abs(simplified.numerator) % Math.abs(simplified.denominator),
            denominator: Math.abs(simplified.denominator)
          }
        : null
    });
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Math Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-purple-500 to-pink-600 p-3 rounded-lg">
            <Divide className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Fraction Calculator</h1>
            <p className="text-gray-600">Add, subtract, multiply, and divide fractions</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Fraction Calculator</h3>
              
              <div className="space-y-6">
                {/* First Fraction */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">First Fraction</label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      value={num1}
                      onChange={(e) => setNum1(Number(e.target.value))}
                      className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center focus:ring-2 focus:ring-purple-500"
                      placeholder="1"
                    />
                    <span className="text-2xl font-bold text-gray-600">/</span>
                    <input
                      type="number"
                      value={den1}
                      onChange={(e) => setDen1(Number(e.target.value))}
                      className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center focus:ring-2 focus:ring-purple-500"
                      placeholder="2"
                    />
                  </div>
                  <div className="mt-2 text-center">
                    <span className="text-lg font-semibold text-purple-600">
                      {num1}/{den1}
                    </span>
                  </div>
                </div>

                {/* Operation */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Operation</label>
                  <div className="flex space-x-2">
                    {['+', '-', '×', '÷'].map((op) => (
                      <button
                        key={op}
                        onClick={() => setOperation(op)}
                        className={`flex-1 py-2 px-4 rounded-lg font-semibold transition-colors ${
                          operation === op
                            ? 'bg-purple-500 text-white'
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                      >
                        {op}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Second Fraction */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Second Fraction</label>
                  <div className="flex items-center space-x-2">
                    <input
                      type="number"
                      value={num2}
                      onChange={(e) => setNum2(Number(e.target.value))}
                      className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center focus:ring-2 focus:ring-purple-500"
                      placeholder="1"
                    />
                    <span className="text-2xl font-bold text-gray-600">/</span>
                    <input
                      type="number"
                      value={den2}
                      onChange={(e) => setDen2(Number(e.target.value))}
                      className="w-20 px-3 py-2 border border-gray-300 rounded-lg text-center focus:ring-2 focus:ring-purple-500"
                      placeholder="3"
                    />
                  </div>
                  <div className="mt-2 text-center">
                    <span className="text-lg font-semibold text-pink-600">
                      {num2}/{den2}
                    </span>
                  </div>
                </div>

                <button
                  onClick={calculateFractions}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
                >
                  Calculate
                </button>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-gray-50 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Result</h3>
              
              {result ? (
                <div className="space-y-4">
                  {/* Calculation Display */}
                  <div className="bg-white p-4 rounded-lg text-center border-2 border-purple-200">
                    <div className="text-2xl font-bold text-gray-800 mb-2">
                      {num1}/{den1} {operation} {num2}/{den2} =
                    </div>
                    <div className="text-3xl font-bold text-purple-600">
                      {result.simplified.numerator}/{result.simplified.denominator}
                    </div>
                  </div>

                  {/* Different Representations */}
                  <div className="bg-white p-4 rounded-lg space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Simplified Fraction</span>
                      <span className="font-bold text-purple-600">
                        {result.simplified.numerator}/{result.simplified.denominator}
                      </span>
                    </div>
                    
                    {result.mixedNumber && (
                      <div className="flex items-center justify-between">
                        <span className="text-gray-600">Mixed Number</span>
                        <span className="font-bold text-blue-600">
                          {result.mixedNumber.whole} {result.mixedNumber.numerator}/{result.mixedNumber.denominator}
                        </span>
                      </div>
                    )}
                    
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Decimal</span>
                      <span className="font-bold text-green-600">{result.decimal}</span>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Percentage</span>
                      <span className="font-bold text-orange-600">{result.percentage}%</span>
                    </div>
                  </div>

                  {/* Additional Info */}
                  <div className="bg-purple-50 p-4 rounded-lg">
                    <p className="text-sm text-purple-800">
                      {result.isImproper 
                        ? '📐 This is an improper fraction (numerator > denominator)'
                        : '📐 This is a proper fraction (numerator < denominator)'
                      }
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Divide size={48} className="text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-500">Enter fractions and click calculate to see results</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FractionCalculator;