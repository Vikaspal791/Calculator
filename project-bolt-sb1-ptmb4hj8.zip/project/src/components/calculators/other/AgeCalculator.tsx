import React, { useState } from 'react';
import { ArrowLeft, Calendar } from 'lucide-react';

interface AgeCalculatorProps {
  onBack: () => void;
}

const AgeCalculator: React.FC<AgeCalculatorProps> = ({ onBack }) => {
  const [birthDate, setBirthDate] = useState<string>('1990-01-01');
  const [targetDate, setTargetDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [result, setResult] = useState<any>(null);

  const calculateAge = () => {
    const birth = new Date(birthDate);
    const target = new Date(targetDate);
    
    if (birth > target) {
      alert('Birth date cannot be after target date');
      return;
    }

    const ageInMs = target.getTime() - birth.getTime();
    const ageInDays = Math.floor(ageInMs / (1000 * 60 * 60 * 24));
    const ageInYears = target.getFullYear() - birth.getFullYear();
    let ageInMonths = target.getMonth() - birth.getMonth();
    let ageInDaysRemainder = target.getDate() - birth.getDate();

    if (ageInDaysRemainder < 0) {
      ageInMonths--;
      const lastMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      ageInDaysRemainder += lastMonth.getDate();
    }

    if (ageInMonths < 0) {
      ageInMonths += 12;
    }

    const adjustedYears = ageInMonths < 0 || (ageInMonths === 0 && ageInDaysRemainder < 0) ? ageInYears - 1 : ageInYears;
    
    setResult({
      exactYears: adjustedYears,
      exactMonths: ageInMonths,
      exactDays: ageInDaysRemainder,
      totalDays: ageInDays,
      totalWeeks: Math.floor(ageInDays / 7),
      totalMonths: adjustedYears * 12 + ageInMonths,
      totalHours: ageInDays * 24,
      totalMinutes: ageInDays * 24 * 60,
      nextBirthday: getNextBirthday(birth, target)
    });
  };

  const getNextBirthday = (birth: Date, current: Date) => {
    const nextBirthday = new Date(current.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBirthday < current) {
      nextBirthday.setFullYear(current.getFullYear() + 1);
    }
    const daysUntil = Math.ceil((nextBirthday.getTime() - current.getTime()) / (1000 * 60 * 60 * 24));
    return daysUntil;
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Other Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-lg">
            <Calendar className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Age Calculator</h1>
            <p className="text-gray-600">Calculate age in years, months, days, and more</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Birth Date
              </label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Calculate Age As Of (Target Date)
              </label>
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={calculateAge}
              className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Calculate Age
            </button>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Age Results</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border-l-4 border-blue-500">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600 mb-2">
                      {result.exactYears} Years
                    </div>
                    <div className="text-lg text-gray-600">
                      {result.exactMonths} Months, {result.exactDays} Days
                    </div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <h4 className="font-semibold text-gray-800">Detailed Breakdown:</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex justify-between">
                      <span>Total Years:</span>
                      <span className="font-semibold">{result.exactYears}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Months:</span>
                      <span className="font-semibold">{result.totalMonths}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Weeks:</span>
                      <span className="font-semibold">{result.totalWeeks}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Days:</span>
                      <span className="font-semibold">{result.totalDays}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Hours:</span>
                      <span className="font-semibold">{result.totalHours.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Minutes:</span>
                      <span className="font-semibold">{result.totalMinutes.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-100 to-blue-100 p-4 rounded-lg">
                  <div className="text-center">
                    <p className="text-sm text-purple-800 mb-1">Next Birthday</p>
                    <p className="text-lg font-semibold text-purple-700">
                      {result.nextBirthday === 0 ? 'Today!' : `${result.nextBirthday} days to go`}
                    </p>
                  </div>
                </div>

                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-sm text-green-800">
                    🎂 You have lived for {result.totalDays.toLocaleString()} days, which is {result.totalWeeks.toLocaleString()} weeks!
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Calendar size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Select dates and click calculate to see your age</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgeCalculator;