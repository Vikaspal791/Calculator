import React, { useState } from 'react';
import { ArrowLeft, Receipt, Users } from 'lucide-react';

interface TipCalculatorProps {
  onBack: () => void;
}

const TipCalculator: React.FC<TipCalculatorProps> = ({ onBack }) => {
  const [billAmount, setBillAmount] = useState<number>(100);
  const [tipPercentage, setTipPercentage] = useState<number>(18);
  const [numberOfPeople, setNumberOfPeople] = useState<number>(1);
  const [result, setResult] = useState<any>(null);

  const calculateTip = () => {
    const tipAmount = (billAmount * tipPercentage) / 100;
    const totalAmount = billAmount + tipAmount;
    const amountPerPerson = totalAmount / numberOfPeople;
    const tipPerPerson = tipAmount / numberOfPeople;

    setResult({
      tipAmount: tipAmount.toFixed(2),
      totalAmount: totalAmount.toFixed(2),
      amountPerPerson: amountPerPerson.toFixed(2),
      tipPerPerson: tipPerPerson.toFixed(2),
      billPerPerson: (billAmount / numberOfPeople).toFixed(2)
    });
  };

  const quickTipOptions = [10, 15, 18, 20, 25];

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Other Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-green-500 to-teal-600 p-3 rounded-lg">
            <Receipt className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">Tip Calculator</h1>
            <p className="text-gray-600">Calculate tips and split bills easily</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bill Amount ($)
              </label>
              <input
                type="number"
                step="0.01"
                value={billAmount}
                onChange={(e) => setBillAmount(Number(e.target.value))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-lg"
                placeholder="100.00"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Tip Percentage (%)
              </label>
              <div className="space-y-3">
                <input
                  type="range"
                  min="0"
                  max="30"
                  value={tipPercentage}
                  onChange={(e) => setTipPercentage(Number(e.target.value))}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={tipPercentage}
                    onChange={(e) => setTipPercentage(Number(e.target.value))}
                    className="w-20 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-center"
                  />
                  <span className="text-gray-600">%</span>
                </div>
              </div>
              
              <div className="flex space-x-2 mt-3">
                {quickTipOptions.map((percentage) => (
                  <button
                    key={percentage}
                    onClick={() => setTipPercentage(percentage)}
                    className={`px-3 py-2 rounded-lg font-semibold transition-colors ${
                      tipPercentage === percentage
                        ? 'bg-green-500 text-white'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {percentage}%
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Number of People
              </label>
              <div className="flex items-center space-x-3">
                <Users className="text-gray-400" size={20} />
                <input
                  type="number"
                  min="1"
                  value={numberOfPeople}
                  onChange={(e) => setNumberOfPeople(Number(e.target.value))}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
            </div>

            <button
              onClick={calculateTip}
              className="w-full bg-gradient-to-r from-green-500 to-teal-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              Calculate Tip
            </button>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">Calculation Results</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-lg border-l-4 border-green-500">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600 mb-1">${result.totalAmount}</div>
                    <div className="text-sm text-gray-600">Total Amount</div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <h4 className="font-semibold text-gray-800">Bill Breakdown:</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Original Bill:</span>
                      <span className="font-semibold">${billAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Tip ({tipPercentage}%):</span>
                      <span className="font-semibold text-green-600">${result.tipAmount}</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span className="font-semibold">Total:</span>
                      <span className="font-bold text-green-600">${result.totalAmount}</span>
                    </div>
                  </div>
                </div>

                {numberOfPeople > 1 && (
                  <div className="bg-white p-4 rounded-lg space-y-3">
                    <h4 className="font-semibold text-gray-800">Per Person:</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Bill per person:</span>
                        <span className="font-semibold">${result.billPerPerson}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Tip per person:</span>
                        <span className="font-semibold text-green-600">${result.tipPerPerson}</span>
                      </div>
                      <div className="flex justify-between border-t pt-2">
                        <span className="font-semibold">Total per person:</span>
                        <span className="font-bold text-blue-600">${result.amountPerPerson}</span>
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-gradient-to-r from-green-100 to-teal-100 p-4 rounded-lg">
                  <p className="text-sm text-green-800">
                    💰 {numberOfPeople > 1 
                      ? `Each person pays $${result.amountPerPerson} (including $${result.tipPerPerson} tip)`
                      : `Total tip: $${result.tipAmount} on a $${billAmount.toFixed(2)} bill`
                    }
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <Receipt size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Enter bill details and click calculate</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TipCalculator;