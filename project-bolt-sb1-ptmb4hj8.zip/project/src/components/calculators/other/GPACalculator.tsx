import React, { useState } from 'react';
import { ArrowLeft, GraduationCap, Plus, Trash2 } from 'lucide-react';

interface Course {
  id: number;
  name: string;
  grade: string;
  credits: number;
}

interface GPACalculatorProps {
  onBack: () => void;
}

const GPACalculator: React.FC<GPACalculatorProps> = ({ onBack }) => {
  const [courses, setCourses] = useState<Course[]>([
    { id: 1, name: 'Mathematics', grade: 'A', credits: 3 },
    { id: 2, name: 'English', grade: 'B+', credits: 4 },
    { id: 3, name: 'Science', grade: 'A-', credits: 3 }
  ]);
  const [result, setResult] = useState<any>(null);

  const gradePoints: { [key: string]: number } = {
    'A+': 4.0, 'A': 4.0, 'A-': 3.7,
    'B+': 3.3, 'B': 3.0, 'B-': 2.7,
    'C+': 2.3, 'C': 2.0, 'C-': 1.7,
    'D+': 1.3, 'D': 1.0, 'D-': 0.7,
    'F': 0.0
  };

  const addCourse = () => {
    const newId = Math.max(...courses.map(c => c.id)) + 1;
    setCourses([...courses, { id: newId, name: '', grade: 'A', credits: 3 }]);
  };

  const removeCourse = (id: number) => {
    setCourses(courses.filter(c => c.id !== id));
  };

  const updateCourse = (id: number, field: keyof Course, value: string | number) => {
    setCourses(courses.map(course => 
      course.id === id ? { ...course, [field]: value } : course
    ));
  };

  const calculateGPA = () => {
    const validCourses = courses.filter(course => course.name.trim() && course.credits > 0);
    
    if (validCourses.length === 0) {
      alert('Please add at least one valid course');
      return;
    }

    let totalQualityPoints = 0;
    let totalCredits = 0;

    validCourses.forEach(course => {
      const points = gradePoints[course.grade] * course.credits;
      totalQualityPoints += points;
      totalCredits += course.credits;
    });

    const gpa = totalQualityPoints / totalCredits;
    
    // Calculate grade distribution
    const gradeDistribution: { [key: string]: number } = {};
    validCourses.forEach(course => {
      gradeDistribution[course.grade] = (gradeDistribution[course.grade] || 0) + 1;
    });

    setResult({
      gpa: gpa.toFixed(2),
      totalCredits,
      totalQualityPoints: totalQualityPoints.toFixed(1),
      courseCount: validCourses.length,
      gradeDistribution,
      letterGrade: getLetterGrade(gpa)
    });
  };

  const getLetterGrade = (gpa: number): string => {
    if (gpa >= 3.7) return 'A';
    if (gpa >= 3.3) return 'B+';
    if (gpa >= 3.0) return 'B';
    if (gpa >= 2.7) return 'B-';
    if (gpa >= 2.3) return 'C+';
    if (gpa >= 2.0) return 'C';
    if (gpa >= 1.7) return 'C-';
    if (gpa >= 1.3) return 'D+';
    if (gpa >= 1.0) return 'D';
    return 'F';
  };

  return (
    <div className="max-w-5xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Other Calculators</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-indigo-500 to-purple-600 p-3 rounded-lg">
            <GraduationCap className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">GPA Calculator</h1>
            <p className="text-gray-600">Calculate your Grade Point Average</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div className="bg-gray-50 p-6 rounded-xl">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">Courses</h3>
                <button
                  onClick={addCourse}
                  className="flex items-center space-x-2 bg-indigo-500 text-white px-4 py-2 rounded-lg hover:bg-indigo-600 transition-colors"
                >
                  <Plus size={16} />
                  <span>Add Course</span>
                </button>
              </div>

              <div className="space-y-4">
                {courses.map((course) => (
                  <div key={course.id} className="bg-white p-4 rounded-lg border">
                    <div className="grid grid-cols-12 gap-3 items-center">
                      <div className="col-span-5">
                        <input
                          type="text"
                          value={course.name}
                          onChange={(e) => updateCourse(course.id, 'name', e.target.value)}
                          placeholder="Course name"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                        />
                      </div>
                      <div className="col-span-3">
                        <select
                          value={course.grade}
                          onChange={(e) => updateCourse(course.id, 'grade', e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                        >
                          {Object.keys(gradePoints).map(grade => (
                            <option key={grade} value={grade}>{grade}</option>
                          ))}
                        </select>
                      </div>
                      <div className="col-span-3">
                        <input
                          type="number"
                          value={course.credits}
                          onChange={(e) => updateCourse(course.id, 'credits', Number(e.target.value))}
                          min="1"
                          max="6"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                        />
                      </div>
                      <div className="col-span-1">
                        <button
                          onClick={() => removeCourse(course.id)}
                          className="text-red-500 hover:text-red-700 p-1"
                          disabled={courses.length === 1}
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button
                onClick={calculateGPA}
                className="w-full mt-6 bg-gradient-to-r from-indigo-500 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
              >
                Calculate GPA
              </button>
            </div>
          </div>

          <div className="bg-gray-50 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-gray-800 mb-4">GPA Results</h3>
            
            {result ? (
              <div className="space-y-4">
                <div className="bg-white p-6 rounded-lg border-l-4 border-indigo-500 text-center">
                  <div className="text-4xl font-bold text-indigo-600 mb-2">{result.gpa}</div>
                  <div className="text-lg text-gray-600">Overall GPA</div>
                  <div className="text-sm text-gray-500 mt-1">Grade: {result.letterGrade}</div>
                </div>

                <div className="bg-white p-4 rounded-lg space-y-3">
                  <h4 className="font-semibold text-gray-800">Summary:</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Total Courses:</span>
                      <span className="font-semibold">{result.courseCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Credits:</span>
                      <span className="font-semibold">{result.totalCredits}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Quality Points:</span>
                      <span className="font-semibold">{result.totalQualityPoints}</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-4 rounded-lg">
                  <h4 className="font-semibold text-gray-800 mb-3">Grade Distribution:</h4>
                  <div className="space-y-2">
                    {Object.entries(result.gradeDistribution).map(([grade, count]) => (
                      <div key={grade} className="flex items-center justify-between text-sm">
                        <span>{grade}:</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-indigo-500 h-2 rounded-full"
                              style={{ width: `${(count / result.courseCount) * 100}%` }}
                            ></div>
                          </div>
                          <span className="font-semibold w-8">{count}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-gradient-to-r from-indigo-100 to-purple-100 p-4 rounded-lg">
                  <p className="text-sm text-indigo-800">
                    🎓 Your GPA of {result.gpa} is equivalent to a {result.letterGrade} average across {result.courseCount} courses.
                  </p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <GraduationCap size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">Add your courses and click calculate to see your GPA</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GPACalculator;