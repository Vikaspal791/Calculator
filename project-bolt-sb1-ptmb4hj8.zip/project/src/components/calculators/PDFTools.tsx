import React, { useState } from 'react';
import { FileText, Upload, Download } from 'lucide-react';
import { calculators } from '../../data/calculators';
import MergePDF from './pdf/MergePDF';
import SplitPDF from './pdf/SplitPDF';
import CompressPDF from './pdf/CompressPDF';

const PDFTools: React.FC = () => {
  const [selectedTool, setSelectedTool] = useState<string>('');

  const renderTool = () => {
    switch (selectedTool) {
      case 'merge-pdf':
        return <MergePDF onBack={() => setSelectedTool('')} />;
      case 'split-pdf':
        return <SplitPDF onBack={() => setSelectedTool('')} />;
      case 'compress-pdf':
        return <CompressPDF onBack={() => setSelectedTool('')} />;
      default:
        return null;
    }
  };

  if (selectedTool) {
    return renderTool();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.pdf.map((tool) => (
          <div
            key={tool.id}
            onClick={() => setSelectedTool(tool.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-orange-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-orange-500 to-red-600 p-3 rounded-lg">
                <FileText className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{tool.name}</h3>
                <p className="text-sm text-orange-600">PDF Tools</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{tool.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-orange-600 font-semibold text-sm">Click to Use</span>
              <FileText size={20} className="text-orange-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PDFTools;