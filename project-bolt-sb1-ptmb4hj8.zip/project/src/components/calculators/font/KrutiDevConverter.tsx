import React, { useState } from 'react';
import { ArrowLeft, Type, ArrowRightLeft } from 'lucide-react';

interface KrutiDevConverterProps {
  onBack: () => void;
}

const KrutiDevConverter: React.FC<KrutiDevConverterProps> = ({ onBack }) => {
  const [inputText, setInputText] = useState<string>('');
  const [outputText, setOutputText] = useState<string>('');
  const [conversionDirection, setConversionDirection] = useState<'krutidev-to-unicode' | 'unicode-to-krutidev'>('krutidev-to-unicode');

  // Sample conversion mappings (simplified for demo)
  const krutidevToUnicodeMap: { [key: string]: string } = {
    'k': 'क',
    'kh': 'ख',
    'g': 'ग',
    'gh': 'घ',
    'c': 'च',
    'ch': 'छ',
    'j': 'ज',
    'jh': 'झ',
    't': 'त',
    'th': 'थ',
    'd': 'द',
    'dh': 'ध',
    'n': 'न',
    'p': 'प',
    'ph': 'फ',
    'b': 'ब',
    'bh': 'भ',
    'm': 'म',
    'y': 'य',
    'r': 'र',
    'l': 'ल',
    'v': 'व',
    's': 'स',
    'h': 'ह',
    'a': 'अ',
    'aa': 'आ',
    'i': 'इ',
    'ii': 'ई',
    'u': 'उ',
    'uu': 'ऊ',
    'e': 'ए',
    'o': 'ओ'
  };

  const unicodeToKrutidevMap: { [key: string]: string } = Object.fromEntries(
    Object.entries(krutidevToUnicodeMap).map(([k, v]) => [v, k])
  );

  const convertText = () => {
    if (!inputText.trim()) {
      setOutputText('');
      return;
    }

    let result = inputText;
    
    if (conversionDirection === 'krutidev-to-unicode') {
      // Convert KrutiDev to Unicode
      Object.entries(krutidevToUnicodeMap).forEach(([krutidev, unicode]) => {
        result = result.replace(new RegExp(krutidev, 'g'), unicode);
      });
    } else {
      // Convert Unicode to KrutiDev
      Object.entries(unicodeToKrutidevMap).forEach(([unicode, krutidev]) => {
        result = result.replace(new RegExp(unicode, 'g'), krutidev);
      });
    }

    setOutputText(result);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputText);
    alert('Text copied to clipboard!');
  };

  const clearText = () => {
    setInputText('');
    setOutputText('');
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Font Converters</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-xl p-8">
        <div className="flex items-center space-x-3 mb-6">
          <div className="bg-gradient-to-r from-amber-500 to-orange-600 p-3 rounded-lg">
            <Type className="text-white" size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-800">KrutiDev ↔ Unicode Converter</h1>
            <p className="text-gray-600">Convert between KrutiDev and Unicode Hindi fonts</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Conversion Direction */}
          <div className="bg-amber-50 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Conversion Direction</h3>
            <div className="flex space-x-4">
              <button
                onClick={() => setConversionDirection('krutidev-to-unicode')}
                className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                  conversionDirection === 'krutidev-to-unicode'
                    ? 'border-amber-500 bg-amber-100'
                    : 'border-gray-200 bg-white hover:border-amber-300'
                }`}
              >
                <div className="text-center">
                  <ArrowRightLeft className="mx-auto mb-2 text-amber-600" size={24} />
                  <div className="font-semibold text-gray-800">KrutiDev → Unicode</div>
                  <div className="text-sm text-gray-600">Convert KrutiDev text to Unicode</div>
                </div>
              </button>
              
              <button
                onClick={() => setConversionDirection('unicode-to-krutidev')}
                className={`flex-1 p-4 rounded-lg border-2 transition-all ${
                  conversionDirection === 'unicode-to-krutidev'
                    ? 'border-amber-500 bg-amber-100'
                    : 'border-gray-200 bg-white hover:border-amber-300'
                }`}
              >
                <div className="text-center">
                  <ArrowRightLeft className="mx-auto mb-2 text-amber-600 transform rotate-180" size={24} />
                  <div className="font-semibold text-gray-800">Unicode → KrutiDev</div>
                  <div className="text-sm text-gray-600">Convert Unicode text to KrutiDev</div>
                </div>
              </button>
            </div>
          </div>

          {/* Input Text Area */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Input Text ({conversionDirection === 'krutidev-to-unicode' ? 'KrutiDev' : 'Unicode'})
            </label>
            <textarea
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Enter your ${conversionDirection === 'krutidev-to-unicode' ? 'KrutiDev' : 'Unicode'} text here...`}
              className="w-full h-32 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
              style={{ fontFamily: conversionDirection === 'krutidev-to-unicode' ? 'monospace' : 'sans-serif' }}
            />
          </div>

          {/* Convert Button */}
          <div className="text-center">
            <button
              onClick={convertText}
              className="bg-gradient-to-r from-amber-500 to-orange-600 text-white py-3 px-8 rounded-lg font-semibold hover:shadow-lg transition-all duration-300 transform hover:scale-105"
            >
              <div className="flex items-center space-x-2">
                <ArrowRightLeft size={20} />
                <span>Convert Text</span>
              </div>
            </button>
          </div>

          {/* Output Text Area */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Output Text ({conversionDirection === 'krutidev-to-unicode' ? 'Unicode' : 'KrutiDev'})
            </label>
            <textarea
              value={outputText}
              readOnly
              placeholder="Converted text will appear here..."
              className="w-full h-32 px-4 py-3 border border-gray-300 rounded-lg bg-gray-50 resize-none"
              style={{ fontFamily: conversionDirection === 'krutidev-to-unicode' ? 'sans-serif' : 'monospace' }}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-4">
            <button
              onClick={copyToClipboard}
              disabled={!outputText}
              className="flex-1 bg-green-500 text-white py-3 px-6 rounded-lg font-semibold hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Copy Output
            </button>
            
            <button
              onClick={clearText}
              className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Clear All
            </button>
          </div>

          {/* Sample Text */}
          <div className="bg-orange-50 p-4 rounded-lg">
            <h4 className="font-semibold text-orange-800 mb-2">Sample Text:</h4>
            <div className="space-y-2 text-sm">
              <div>
                <span className="font-medium">KrutiDev:</span>
                <span className="ml-2 font-mono">namaste duniya</span>
              </div>
              <div>
                <span className="font-medium">Unicode:</span>
                <span className="ml-2">नमस्ते दुनिया</span>
              </div>
            </div>
            <p className="text-xs text-orange-700 mt-2">
              Note: This is a simplified converter for demonstration. A full implementation would include complete character mappings and advanced conversion rules.
            </p>
          </div>

          {/* Instructions */}
          <div className="bg-amber-50 p-4 rounded-lg">
            <h4 className="font-semibold text-amber-800 mb-2">How to use:</h4>
            <ul className="text-sm text-amber-700 space-y-1">
              <li>1. Choose the conversion direction (KrutiDev to Unicode or vice versa)</li>
              <li>2. Paste or type your text in the input area</li>
              <li>3. Click "Convert Text" to perform the conversion</li>
              <li>4. Copy the converted text from the output area</li>
              <li>5. Use the converted text in your documents or applications</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KrutiDevConverter;