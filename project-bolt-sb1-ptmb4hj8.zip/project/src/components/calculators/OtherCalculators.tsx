import React, { useState } from 'react';
import { Wrench, Clock, Calculator as CalcIcon } from 'lucide-react';
import { calculators } from '../../data/calculators';
import AgeCalculator from './other/AgeCalculator';
import GPACalculator from './other/GPACalculator';
import TipCalculator from './other/TipCalculator';

const OtherCalculators: React.FC = () => {
  const [selectedCalculator, setSelectedCalculator] = useState<string>('');

  const renderCalculator = () => {
    switch (selectedCalculator) {
      case 'age':
        return <AgeCalculator onBack={() => setSelectedCalculator('')} />;
      case 'gpa':
        return <GPACalculator onBack={() => setSelectedCalculator('')} />;
      case 'tip':
        return <TipCalculator onBack={() => setSelectedCalculator('')} />;
      default:
        return null;
    }
  };

  if (selectedCalculator) {
    return renderCalculator();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.other.map((calculator) => (
          <div
            key={calculator.id}
            onClick={() => setSelectedCalculator(calculator.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-purple-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-purple-500 to-violet-600 p-3 rounded-lg">
                <Wrench className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{calculator.name}</h3>
                <p className="text-sm text-purple-600">Utility Tools</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{calculator.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-purple-600 font-semibold text-sm">Click to Calculate</span>
              <CalcIcon size={20} className="text-purple-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OtherCalculators;