import React, { useState } from 'react';
import { Heart, Activity, Calculator as CalcIcon } from 'lucide-react';
import { calculators } from '../../data/calculators';
import BMICalculator from './health/BMICalculator';
import CalorieCalculator from './health/CalorieCalculator';
import BMRCalculator from './health/BMRCalculator';

const HealthCalculators: React.FC = () => {
  const [selectedCalculator, setSelectedCalculator] = useState<string>('');

  const renderCalculator = () => {
    switch (selectedCalculator) {
      case 'bmi':
        return <BMICalculator onBack={() => setSelectedCalculator('')} />;
      case 'calorie':
        return <CalorieCalculator onBack={() => setSelectedCalculator('')} />;
      case 'bmr':
        return <BMRCalculator onBack={() => setSelectedCalculator('')} />;
      default:
        return null;
    }
  };

  if (selectedCalculator) {
    return renderCalculator();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.health.map((calculator) => (
          <div
            key={calculator.id}
            onClick={() => setSelectedCalculator(calculator.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-red-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-red-500 to-pink-600 p-3 rounded-lg">
                <Heart className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{calculator.name}</h3>
                <p className="text-sm text-red-600">Health & Fitness</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{calculator.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-red-600 font-semibold text-sm">Click to Calculate</span>
              <CalcIcon size={20} className="text-red-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HealthCalculators;