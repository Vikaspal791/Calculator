import React, { useState } from 'react';
import { ArrowRightLeft, Thermometer } from 'lucide-react';
import { calculators } from '../../data/calculators';
import UnitConverter from './conversion/UnitConverter';
import TemperatureConverter from './conversion/TemperatureConverter';

const ConversionTools: React.FC = () => {
  const [selectedConverter, setSelectedConverter] = useState<string>('');

  const renderConverter = () => {
    switch (selectedConverter) {
      case 'unit-converter':
        return <UnitConverter onBack={() => setSelectedConverter('')} />;
      case 'temperature-converter':
        return <TemperatureConverter onBack={() => setSelectedConverter('')} />;
      default:
        return null;
    }
  };

  if (selectedConverter) {
    return renderConverter();
  }

  return (
    <div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {calculators.conversion.map((converter) => (
          <div
            key={converter.id}
            onClick={() => setSelectedConverter(converter.id)}
            className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6 border-l-4 border-lime-500"
          >
            <div className="flex items-center space-x-3 mb-4">
              <div className="bg-gradient-to-r from-lime-500 to-green-600 p-3 rounded-lg">
                <ArrowRightLeft className="text-white" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-800">{converter.name}</h3>
                <p className="text-sm text-lime-600">Conversion Tool</p>
              </div>
            </div>
            <p className="text-gray-600 text-sm mb-4">{converter.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-lime-600 font-semibold text-sm">Click to Convert</span>
              <ArrowRightLeft size={20} className="text-lime-500" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ConversionTools;