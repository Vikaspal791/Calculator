import React from 'react';
import { ArrowLeft, Calculator } from 'lucide-react';

interface SearchResultsProps {
  query: string;
  results: any[];
  onCalculatorSelect: (calculatorId: string) => void;
  onBack: () => void;
}

const SearchResults: React.FC<SearchResultsProps> = ({ query, results, onCalculatorSelect, onBack }) => {
  return (
    <div className="py-8">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Home</span>
        </button>
      </div>

      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Search Results for "{query}"
        </h1>
        <p className="text-xl text-gray-600">
          Found {results.length} calculator{results.length !== 1 ? 's' : ''} matching your search
        </p>
      </div>

      {results.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {results.map((calculator, index) => (
            <div
              key={index}
              onClick={() => onCalculatorSelect(calculator.id)}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 cursor-pointer p-6"
            >
              <div className="flex items-center space-x-3 mb-4">
                <div className="bg-gradient-to-r from-blue-500 to-purple-500 p-2 rounded-lg">
                  <Calculator className="text-white" size={20} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800">{calculator.name}</h3>
                  <p className="text-sm text-gray-500">{calculator.category}</p>
                </div>
              </div>
              <p className="text-gray-600 text-sm">{calculator.description}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Calculator size={64} className="text-gray-400 mx-auto mb-4" />
          <h3 className="text-2xl font-semibold text-gray-600 mb-2">No calculators found</h3>
          <p className="text-gray-500">Try searching with different keywords or browse our categories</p>
        </div>
      )}
    </div>
  );
};

export default SearchResults;