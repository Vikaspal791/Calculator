import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { calculators } from '../data/calculators';
import FinancialCalculators from './calculators/FinancialCalculators';
import HealthCalculators from './calculators/HealthCalculators';
import MathCalculators from './calculators/MathCalculators';
import OtherCalculators from './calculators/OtherCalculators';
import PDFTools from './calculators/PDFTools';
import ImageTools from './calculators/ImageTools';
import FontConverters from './calculators/FontConverters';
import ConversionTools from './calculators/ConversionTools';

interface CalculatorPageProps {
  calculatorId: string;
  onBack: () => void;
}

const CalculatorPage: React.FC<CalculatorPageProps> = ({ calculatorId, onBack }) => {
  const renderCalculatorComponent = () => {
    switch (calculatorId) {
      case 'financial':
        return <FinancialCalculators />;
      case 'health':
        return <HealthCalculators />;
      case 'math':
        return <MathCalculators />;
      case 'other':
        return <OtherCalculators />;
      case 'pdf':
        return <PDFTools />;
      case 'image':
        return <ImageTools />;
      case 'font':
        return <FontConverters />;
      case 'conversion':
        return <ConversionTools />;
      default:
        return <div>Calculator not found</div>;
    }
  };

  const getCategoryTitle = () => {
    const categoryTitles: { [key: string]: string } = {
      financial: 'Financial Calculators',
      health: 'Fitness & Health Calculators',
      math: 'Math Calculators',
      other: 'Other Calculators',
      pdf: 'PDF Tools',
      image: 'Image Tools',
      font: 'Font Converters',
      conversion: 'Conversion Tools'
    };
    return categoryTitles[calculatorId] || 'Calculators';
  };

  return (
    <div className="py-8">
      <div className="flex items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-semibold transition-colors"
        >
          <ArrowLeft size={20} />
          <span>Back to Home</span>
        </button>
      </div>

      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
          {getCategoryTitle()}
        </h1>
        <p className="text-xl text-gray-600">
          Choose from our collection of professional calculators and tools
        </p>
      </div>

      {renderCalculatorComponent()}
    </div>
  );
};

export default CalculatorPage;